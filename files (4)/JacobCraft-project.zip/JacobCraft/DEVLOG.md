# Jacob Craft — development log

## Architecture notes
- Custom WebGL2 engine, ES modules, no build step. Dev server: `python serve.py` (forces JS MIME types, no-cache).
- World: 16x16x192 chunk columns, sea level 63. Block ids are Uint8 (order in `world/blocks.js` = save format; only append).
- Generation runs in `workers/genWorker.js` (terrain/caves/ores/trees/plants/snow + local light).
  Cross-chunk light merge + edits use BFS in `world/world.js`.
- Meshing runs in `workers/meshWorker.js` on padded 18x18 copies; vertex = 20 bytes
  (int16 pos/128, uv/32, uint16 layer, sky/block light, AO, emissive, tint rgb, material|reflect<<3).
- Renderer passes: shadow (distorted ortho) → sky LUT → env map → clouds (low-res raymarch) → sky →
  opaque chunks + entities (MRT color+normal/reflectivity) → SSR (wet/polished) → water (refraction+SSR) →
  particles/precip/overlays/hand → volumetric light → bloom → auto exposure → ACES composite → FXAA.
- Textures: 32x32 procedural (`gfx/texgen.js`), albedo SRGB array + normal/tintmask/smoothness array.
  NOTE: no anisotropic filtering (it forces linear filtering on ANGLE → blurry pixel art).
- Entities: instanced box models with procedural pixel patterns (`gfx/entityRenderer.js`), extruded item meshes.
- Items: ids 0-255 = blocks, 256+ = items (`game/items.js`, append only).
- Saves: IndexedDB `jacobcraft` (worlds store + RLE chunks store).
- Hidden preview panes throttle rAF → main loop has a setInterval fallback.
- `jc` (window) = App debug handle; `jc.game.debugActive = true` lets scripts drive the player without pointer lock.
- Phase 6 systems install as hook chains from `game/extensions.js` (`installExtensions`): each wraps the previous
  `game.extUpdate`, `ui.updateHUD`, `game.onPlayerHurt`, `game.restoreSpecial`, `game.onPickup`. New systems should
  follow the same pattern instead of editing the core loop.
- Item stacks are `{id, count, dmg}` plus optional extras (`ench`, `loaded`, `name`) — always copy them with
  `stackExtra()` when moving/dropping stacks.
- World generation ends with a cleanup pass (`world/worldgen.js`): lone terrain/leaf voxels and detached clumps of up
  to 12 natural blocks are removed; anything touching a log, a structure block, liquid below, or the chunk border is
  kept. Tree generators must stay face-connected (step one axis at a time) (to verify a new type:
  grow it in an empty grid and flood-fill from the base; nothing may be left over).
- Player saves remember a persistent mount (dragon/horse/boat); on load the player is held in place until the mount's
  chunk restores it, then remounted (or set down on the ground if it is gone).

## Status
- Phase 1: DONE (movement, mining/tool tiers, placement, inventory, crafting + recipe book, furnace, chest, save/load, menus).
- Phase 2: DONE (health/hunger/air/damage/death/respawn, day/night, sleeping, animals, monsters, AI, spawning,
  taming wolves/cats/horses, horse riding, breeding, shearing, bows/arrows, projectiles).
- Phase 3: DONE (weather system + lightning + snow + wetness, SSR water, villages in 6 biome styles with villagers on
  daily schedules, A* pathing, doors, farming, trading, dialogue/lore hints; ruins, wizard towers, shipwrecks,
  mineshafts, loot chests; rowable boats).
- Phase 4: DONE. Five bosses (Woolly Mammoth, Forest Warden, Desert Titan, Frost Wyrm, Volcanic Behemoth) with lairs,
  wake-up, attack sets, phase 2, boss bar; wizard quests.
- Phase 5: DONE. Dragons at roosts: befriend with Dragonfruit Treats (trust 3 = friend, 6 = tamed), saddle, ride, fly,
  boost, fire breath.
- Phase 6 ("The Frontier Update"): DONE. First-person hands/swing keyframes and 3D held models; player model ("Jacob")
  with armor; reworked animals/monsters/villagers (person models, hats, props, greeting wave); swords, daggers, spears
  (thrown), maces, crossbows, Emberlock Pistol, Thunder Blunderbuss, gunpowder, TNT; brewing (Alchemy Table) and
  enchanting (Runic Altar, Runic Tomes, XP); 56 new blocks (building, decor, ores, stations) incl. sit-able furniture, campfire cooking;
  stylised damage feedback (splats, vignette, flinch, hit-stop, captions); birds/butterflies/fireflies; biome fog
  tints, dawn mist, sun glare; display modes, UI/render scale, key rebinding, accessibility toggles; title screen
  redesign; boss intros, per-boss music, loot fountains with beams, Boss Blessings and boss-forged gear.
- Phase 7 (QA + polish): DONE — see below.

## Phase 7 QA log (2026-10)
- Core loop harness (punch tree, craft, place, eat, melee kill, die/respawn, swim, bow, potion, trade): pass.
- Save/quit/reload keeps position, inventory extras (enchantments, loaded crossbow), XP, blessings, and now the mount.
- Worldgen: 20 spots across 4 fresh seeds (all major biomes) scanned for floating blocks — 0 after fixes. Fixed:
  trunk vines punching holes in canopies, detached willow strands, diagonal palm trunks/fronds, diagonal elder roots,
  a cleanup bookkeeping bug that deleted attached fronds, lone border terrain voxels. Tree unit check: all 15 types
  fully face-connected.
- Bosses: all five fought in sequence — intro card + letterbox, 2–4 attack types each, phase 2, death sequence,
  loot fountain, blessing; no errors. Fixed: summoned rootlings/scorpions now crumble with their boss; a pending
  blessing subtitle no longer overlaps the next boss card.
- Weather: storm, lightning bolts, rain, heavy rain, snow transition in tundra, fog — visually checked.
- Dragon: tame (6 treats), saddle gate, mount, take-off, ~13 b/s cruise, ~23 b/s boost, fire breath.
- Boats: float, paddle, steer. Crossbow/pistol/blunderbuss load+ammo+damage, TNT crater and falloff damage.
- Brewing (water → tonic → healing, fuel charges) and enchanting (offers, XP + dust cost) end to end; wizard quest.
- UI at 375×812, 700×500, 1280×600, 1920×1080: title (splash no longer covers the tagline), all settings tabs (key
  binds go single-column when narrow), HUD, inventory (auto UI scale now also follows window width). Inventory
  preview box now draws a live portrait of Jacob with his armor, head following the mouse.
- Sky: below-horizon haze no longer darkens into khaki when seen from the air.
- New worlds now face the player toward the most open view (scored raycasts in 16 directions) instead of
  whatever wall or trunk happened to be in front of the spawn point.
- Performance (hidden-pane measurements): ~1.4 ms update + ~2.4 ms render submit per frame on CPU; chunk generation
  ~5 ms per chunk in the worker.

## v1.1 "The Worldheart Update" — finishing the game (2026-10)
- Spec gap closed: **mini-bosses** (`mobs/minibosses.js`). Six champions built on the regular monsters (crowned,
  recoloured, scaled models; 140–170 hp; enrage at half health; health bar; two abilities each from a shared kit:
  summon/brood, ground slam, tongue pull, burrow-and-erupt, ice volley, frost nova, fireball barrage, fire ring).
  At most one alive; rare rolls (5% every 20 s, 4-minute cooldown after a kill) in their home biome at night, or the
  Broodmother when deep underground. Drops: Wayfinder Shards, emeralds, glow dust, sometimes a diamond.
- **Ending** (`game/journey.js`): Worldheart Keystone used on a Runic Altar (gated on all five Boss Blessings) plays a
  ritual cinematic (five coloured beams, a pillar of light), then an ending text, credits, and the player's journey
  statistics. Esc skips to the credits; "Continue your adventure" returns to a new dawn with a Dragon Egg on the altar.
- **Journal** (J / pause menu): 21 milestones, the five great beasts with lair hints, the Worldheart steps.
  Journey data and stats (mined, placed, killed, deaths, distance, time) are saved with the player.
- Placeholder items made real: the compass points home (bed or world spawn), the spyglass zooms (hold use), the
  Dragon Egg hatches a tamed hatchling that grows up in ~10 minutes (treats speed it up; too young to saddle).
- New: Wayfinder Shard, Lair Compass (points to the nearest undefeated great beast's lair via the structure locator),
  Worldheart Keystone.
- Fixes found along the way: blood splats could float mid-air (they formed when a drop hit a wall sideways) or
  underwater; large melee mobs walked into the player instead of stopping at arm's length; respawning at a destroyed
  bed; a held Esc could close two screens at once; the burrow eruption almost never connected.

## Hands, tools and animation fixes (2026-10)
- **First-person rig rebuilt** (`game/hands.js`): Jacob's fist (knuckles, curled fingers, thumb) on a straight forearm
  with a rolled cream cuff and his blue sleeve running back to a shoulder off screen. Tools are real 3D models now
  (`toolModel()` in `gfx/heldModels.js`: pickaxe, axe, shovel, hoe, sword, dagger, mace in every tier's colours),
  held with the head facing the target — the old sprite axe was mirrored twice and showed its blade to the player.
- **Swings** use smooth strike curves (`swingPose`): a chop that brings the tool head forward and down onto the
  crosshair, a diagonal sword slash, a straight punch. No wind-up backwards and no sideways sweep.
- **Shadows**: the entity shadow pass used to draw whatever was left in the box buffer — the first-person arm — so the
  arm shadowed itself (jagged black triangles) and creatures barely cast shadows. Entity boxes are now snapshotted
  after drawing (`snapshotShadow` / `drawShadowSnapshot`), and the hand and held item ignore world shadows.
- **Animation convention**: models face -Z, where a positive pitch swings a limb forward / raises a head, but every
  creature animation had been written the other way round (grazing heads went up, shambler arms reached behind their
  backs, attacks wound backwards, mobs looked away from targets). `Mob.render` now mirrors the animated part of each
  pitch (rest poses untouched). Jacob's third-person poses (swing, aiming, eating, riding, sneaking) were corrected
  by hand in `game/playerModel.js`; tools there ride on the arm, pointing forward.
- **Breaking**: crack overlay is one fracture network that spreads across the face stage by stage, sampled at full
  resolution so it stays visible at a distance. **Stone** (and the ores set in it) and **cobblestone** are darker.
- **Hunger** drains faster: a small steady drain, walking costs a little, mining costs more (a full bar lasts roughly
  20–30 minutes of ordinary play).
- **Fewer pop-ups**: minor milestones are recorded silently in the Journal; rare-item cards only on the first pickup;
  new one-time discovery cards for ruins, ancient ruins, abandoned mineshafts (from inside), shipwrecks, wizard towers
  and dragon roosts (counted as "Places discovered" in the end stats).

## Final completion update, part 1 (2026-10)
- **Off-hand** (F swaps): torches light the area while held, food, blocks and tools work from the left hand.
- **Shields in five tiers** (all hold in either hand, block from the front only): Wooden (lets 30% through),
  Iron, Diamond (raises fastest, hardest knockback), Ember Bulwark (sets attackers alight) and the Scarab Aegis
  (dropped by Ankhuret; a blocked blow bursts into sand and staggers everything in front). Each has its own icon and
  3D model.
- **Combat**: weapon-specific attack speeds with a half-cycle lockout and a charge curve; hit effects land on the
  swing's impact; first-person strikes travel toward the target.
- **Jacob**: rugged, weathered look (beard, scar, coat, gloves, satchel); the inventory portrait is now z-buffered,
  so his eyes and face always draw correctly.
- **Horses**: hold Space to gather a jump (bar under the crosshair), jump/landing sounds and dust, tucked-leg leaps,
  landing squash, smooth turning with a lean, gaits with hoof beats, pawing at rest, a bridle and reins; the rider
  sits on the animated saddle and dismounts beside the horse, never into a wall. Camels ride the same way (better on sand).
- **Gloomstalker rebuilt**: 3 m, hunched, jointed limbs, split maw, pin-prick eyes. It creeps closer only while
  unwatched; meet its gaze and it screams and charges or blinks behind you; once hunting it rushes, freezes and
  steps through the dark. Teleports now find real standing room (no more popping out of caves onto the surface).
- **The Wickwalker** (new, very rare, harmless): a figure in a patchwork coat and porcelain mask with a dead lantern
  and circling moths, watching from the edge of the light at night or deep underground. Approach and it comes apart
  into moths; sometimes it leaves a Pale Wick (crafts Moth Lanterns).
- **Wildlife**: songbirds, owls (in the canopy at night), parrots, vultures and eagles circling overhead, ridge goats,
  ridge lynx, camels, tapirs, sand lizards, snow hares, Glimmerstag (rare), Frostfang and Cinder Hounds (night),
  magma beetles, bog wisps, dragonflies, fireflies, dolphins, sharks, glow jellies, lanternfish, red foxes.
  Desert scorpions are far rarer (no daytime scorpions at all).
- **Cats and foxes** rebuilt: front-facing eyes with a glint, whiskers, pointed ears, bushy fox tails; they sit,
  wash, sleep curled up, and foxes pounce. Tame cats purr.
- **The Sunken Pyramid**: rare, on open desert. Dart-trap entrance, grand hall with a sun mural, treasure room over a
  collapsing floor, offering room with a hidden passage (and a sand trap that seals the way back), secret chamber,
  and a tomb arena below where **Ankhuret, the Gilded Husk** sleeps (sweep, sun lance, scarab swarms; enraged, his
  carapace opens into wings and he swims through the sand). Drops the Gilded Khopesh, the Husk-King's Nemes
  (night sight), the Scarab Aegis, treasure and a Wayfinder Shard.
- **New blocks**: brazier, wall sconce, paper lantern, moth lantern, oil lamp, wall shelf, wooden sign (write on
  it; the words show when you look at it), stone hearth (with fire), brick chimney (smokes over a hearth), clay urn,
  sandstone pressure plate.
- **Recipe book**: recipes reveal themselves when you first hold an ingredient (a quiet note by the hotbar, a gold
  dot on new ones), a count of what's left to discover, and a Smelt tab. Recipes added for everything new and for
  blocks that had none.
- **TNT Launcher**: hold use to load a TNT, use to lob it; it bursts on impact.
- **Blood** (toggle in settings): fuller spray and mist, splats that dry and darken, drip trails from wounded
  creatures, and a pool where one falls.
- **Fix**: every entity shadow draw had been silently failing (a sampler bound to the wrong texture during the shadow
  pass), so creatures and Jacob never cast sun shadows. They do now.

## Final completion update, part 2 (2026-10)
- **Beds** rebuilt: wooden frame on legs, headboard and footboard, a ticking-striped mattress, a plump pillow and a
  quilted blanket draped over the sides; six colours (red, blue, green, yellow, violet, white; craft with matching
  wool). **Bed spawn fix**: you used to respawn on top of whatever was above your bed (the roof) because respawning
  lifted you to the highest block in the column; waking and respawning now put you on the floor beside the bed.
- **Winter villages**: the "missing roof" look came from loose snow layers hovering half a block over the stepped
  roof, which from a distance read as holes. Roofs now use snow-topped pine steps. Cold-country houses (snowy and
  taiga) get a stone hearth with a live fire, a brick chimney that smokes, a rug and a shelf; snow drifts bank up
  against the walls (only on solid ground). Snowy villages use warm lanterns.
- **Village life**: a fuller day: wake, work, errands to the other houses and workshops (a third of the village),
  a midday gathering at the well, evening socialising, sleep. Villagers stop to chat in pairs (turn-taking gestures
  and murmurs), hurry home in a downpour or storm but stay out in light snow.
- **Fixes**: villagers wedged against one-block steps on their routes and never re-planned; they now step up, hop
  when stuck and re-path. Rugs no longer block the pathfinder.
- **Village chests** match the household (farmer, fisher, librarian, healer, builder, hunter, merchant, apprentice),
  mostly modest.
- **The Hearthwarden** (village guardian): a stone-and-timber construct with a hearth-fire in its chest and a little
  shingle roof for a brow. It walks the lanes by day and keeps the well at night, smashes monsters that come into the
  village with a two-fisted slam, and turns on anyone who hurts its villagers. One per village; if it falls, the
  villagers raise another after a few days.

## Final completion update, part 3 (2026-10)
- **Jacob** now has the classic blocky-adventurer look: short dark-brown hair and stubble, teal T-shirt, bare
  forearms, blue jeans, grey shoes. No gloves (first person shows bare hands and a teal sleeve).
- **Grip**: with a pickaxe, axe, shovel, hoe, sword or mace the fist turns so the handle runs along the curled
  fingers, thumb towards the head, and follows the tool's angle (both hands).
- **Ears**: every four-legged creature's ears had been drawn at foot level (ear positions are relative to the head
  but were used as absolute). Wolves, foxes, cats, horses, deer, cows and the rest have their ears back.
- **Wolves** rebuilt to be cuter: big soft head, perky ears, round amber eyes, short muzzle, fluffy curled tail;
  tamed wolves wear a red collar and can sit. Foxes have bigger ears.
- **Monsters** spawn less (hostile cap 14 -> 8, half the spawn attempts). The Gloomstalker is about four times rarer
  and never more than one at a time; while one has you in sight the edges of the screen darken and you hear your
  heartbeat; meeting its eyes tears the picture with static. Its eyes burn brighter.
- **Sounds**: the synthesised footsteps, jump/landing and pickup sounds are gone. Pickup plays a recorded sound if a
  file is placed at `assets/sounds/pickup.ogg` (or .mp3/.wav). Animals call half as often; pig and chicken calls
  are softer.
- **Inventory**: drag the held stack across slots to share it out evenly (left button) or drop one in each (right
  button); splitting keeps enchantments and other item data. **Creative** inventory redesigned: category tabs
  (Building, Nature, Decor & Light, Tools & Combat, Food, Materials, Rare), search, a grid that fits the panel and a
  fixed delete bin.
- **Journal** is an adventure notebook: paper pages with ribbon tabs: Journey (stats and milestones), Bestiary
  (ink sketches of every creature you've met, with notes), Atlas (lands walked, places found), Beasts (great beasts,
  champions, other bosses, the Worldheart steps), Recipes, and Notes you can write yourself.
- Main menu kept as originally designed (by request).

## The Caves Update (2026-10)
- **Caves**: giant caverns (tallest around y 30), wider tunnels and cheese caves, pointed dripstone and dripstone
  columns, glowcaps and mushrooms on cave floors. Underground the distance now fades to darkness instead of sky haze.
- **Ores**: iron about twice as common (and up to y 110), more coal and gold, and ore veins seeded on cave walls:
  diamonds glint in the walls of the deepest caves.
- **Dungeons**: mossy cobblestone rooms with a monster spawner and loot chests, found where caves run through.
  **Mineshafts**: a second, deeper shaft per region, rails, posts holding walkways up over caverns, and a cave
  crawler nest (spawner wrapped in cobwebs). **Spawners** keep calling monsters while you are near; break them.
- **The Broodmother's Den**: a vast domed cavern deep underground with pillars, webs, bones and crawler nests, and a
  tunnel up to a ruined arch at the surface (`/locate den`). Walk in and the Broodmother drops from the ceiling;
  killing her silences the den and its nests.
- **Creepers** (hiss, swell, flash, explode; step away and they calm down) and **Skeletons** (archers that keep
  their distance and burn in daylight) at night and in caves.
- **Villages**: path blocks were drawn black (their sunken top read their own dark cell's light) and stopped you at
  doorways (the step-up bumped your head on the lintel); both fixed, and creatures step over small lips too. Roofs
  are now built after every house, so a neighbour can't strip them; saved worlds get missing roofs patched once
  when those chunks load. House windows use the new glass panes.
- **Clouds**: no more crawling noise or streaky bands at the horizon (fixed dither, a soft filter, and the layer
  melts into the haze near the horizon).
- **Weapons**: Double-Barrel Shotgun (two shells per load, eight pellets a shot) with Shotgun Shells; Flint, Iron
  and Diamond Knives (quick, weaker than a sword). Shields are held smaller in first person so they don't fill
  the view.
- **Blocks**: Glass Pane (joins up with neighbours), Rail, Monster Spawner, Dripstone, Pointed Dripstone.
- **First person**: blocky Minecraft-style arms (one square block, sleeve and bare hand, a little slimmer, with a
  pixel-grain skin texture and woven sleeves) for every character. The
  bow comes up to the middle of the view and squares up as you draw, and kicks forward when you loose.
- **Character creator**: type your own name in the box above your adventurer and build their look: start from one
  of five unnamed presets, then pick skin, hair style and colour, eyes, facial hair, shirt, sleeves, trousers, shoes and build, with a preview
  you drag to turn (or Randomize). Shown for each new world (and once for older worlds), then an illustrated intro
  tells the story of the Worldheart and what to do. The name is used in chat, death messages, the journal, the
  intro and the credits.
- **Emotes** (B): wave, dance, cheer, clap, point, bow, sit, laugh; the camera turns round to watch; villagers wave
  back.
- **Scarier and rarer**: the Wickwalker turns up about half as often and only after day 3; it creeps closer every
  time you look away, its eyes light up and its head cocks over while you stare, and it does not leave quietly if
  you get close. Gloomstalkers are half as common again. Champions are half as likely, never in the first minutes of
  a session, and arrive with a roar, a red pulse and your heartbeat.
