// Ink sketches of creature models for the journal: the model's rest pose, turned three-quarters, z-buffered and
// drawn in sepia on transparent "paper", with dark outlines where the silhouette or depth breaks.
import { mat4 } from '../core/math.js';

const CACHE = new Map();
const FACES = [[0, 1, 3, 2, [-1, 0, 0]], [4, 6, 7, 5, [1, 0, 0]], [0, 4, 5, 1, [0, -1, 0]], [2, 3, 7, 6, [0, 1, 0]], [0, 2, 6, 4, [0, 0, -1]], [1, 5, 7, 3, [0, 0, 1]]];

export function sketchModel(model, w = 150, h = 110, key = null) {
  if (key && CACHE.has(key)) return CACHE.get(key);
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  if (!model || !model.parts) return cv.toDataURL();
  // pose the parts at rest
  const mats = [];
  model.parts.forEach((pt, i) => {
    const M = mat4.create();
    if (pt.pi >= 0) M.set(mats[pt.pi]);
    const r = pt.rest || [0, 0, 0], pv = pt.pivot;
    mat4.translate(M, M, pv[0], pv[1], pv[2]);
    if (r[1]) mat4.rotateY(M, M, r[1]);
    if (r[0]) mat4.rotateX(M, M, r[0]);
    if (r[2]) mat4.rotateZ(M, M, r[2]);
    mat4.translate(M, M, -pv[0], -pv[1], -pv[2]);
    mats[i] = M;
  });
  const yaw = 0.62, pitch = -0.22, cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
  const view = (x, y, z) => { const X = x * cy + z * sy, Z0 = -x * sy + z * cy; return [X, y * cp - Z0 * sp, y * sp + Z0 * cp]; };
  const tris = [];
  let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
  const L = [-0.5, 0.75, -0.45];
  model.parts.forEach((pt, i) => {
    if (pt.sleepOnly) return;
    const M = mats[i], pv = pt.pivot;
    for (const b of pt.boxes) {
      const o = [pv[0] + b.o[0], pv[1] + b.o[1], pv[2] + b.o[2]], s = b.s;
      const V = [];
      for (let k = 0; k < 8; k++) {
        const x = o[0] + (k & 4 ? s[0] : 0), y = o[1] + (k & 2 ? s[1] : 0), z = o[2] + (k & 1 ? s[2] : 0);
        const wx = M[0] * x + M[4] * y + M[8] * z + M[12], wy = M[1] * x + M[5] * y + M[9] * z + M[13], wz = M[2] * x + M[6] * y + M[10] * z + M[14];
        const v = view(wx, wy, wz); V.push(v);
        x0 = Math.min(x0, v[0]); x1 = Math.max(x1, v[0]); y0 = Math.min(y0, v[1]); y1 = Math.max(y1, v[1]);
      }
      for (const f of FACES) {
        const a = V[f[0]], bb = V[f[1]], c = V[f[2]];
        const nx = (bb[1] - a[1]) * (c[2] - a[2]) - (bb[2] - a[2]) * (c[1] - a[1]);
        const ny = (bb[2] - a[2]) * (c[0] - a[0]) - (bb[0] - a[0]) * (c[2] - a[2]);
        const nz = (bb[0] - a[0]) * (c[1] - a[1]) - (bb[1] - a[1]) * (c[0] - a[0]);
        const nl = Math.hypot(nx, ny, nz) || 1;
        const lum = (b.c[0] * 0.3 + b.c[1] * 0.55 + b.c[2] * 0.15);
        const lit = 0.55 + 0.45 * Math.abs((nx * L[0] + ny * L[1] + nz * L[2]) / nl);
        const glow = b.p === 13;
        tris.push([a, bb, c, lum, lit, glow], [a, c, V[f[3]], lum, lit, glow]);
      }
    }
  });
  const pad = 6, sc = Math.min((w - pad * 2) / (x1 - x0 || 1), (h - pad * 2) / (y1 - y0 || 1));
  const ox = w / 2 - (x0 + x1) / 2 * sc, oy = h / 2 + (y0 + y1) / 2 * sc;
  const Z = new Float32Array(w * h).fill(1e9), T = new Float32Array(w * h).fill(-1), ID = new Int32Array(w * h).fill(-1);
  tris.forEach(([a, b, c, lum, lit, glow], ti) => {
    const P = [a, b, c].map(v => [ox + v[0] * sc, oy - v[1] * sc, v[2]]);
    const area = (P[1][0] - P[0][0]) * (P[2][1] - P[0][1]) - (P[1][1] - P[0][1]) * (P[2][0] - P[0][0]);
    if (Math.abs(area) < 1e-6) return;
    const minx = Math.max(0, Math.floor(Math.min(P[0][0], P[1][0], P[2][0]))), maxx = Math.min(w - 1, Math.ceil(Math.max(P[0][0], P[1][0], P[2][0])));
    const miny = Math.max(0, Math.floor(Math.min(P[0][1], P[1][1], P[2][1]))), maxy = Math.min(h - 1, Math.ceil(Math.max(P[0][1], P[1][1], P[2][1])));
    for (let y = miny; y <= maxy; y++) for (let x = minx; x <= maxx; x++) {
      const px = x + 0.5, py = y + 0.5;
      const w0 = ((P[1][0] - px) * (P[2][1] - py) - (P[1][1] - py) * (P[2][0] - px)) / area;
      const w1 = ((P[2][0] - px) * (P[0][1] - py) - (P[2][1] - py) * (P[0][0] - px)) / area;
      const w2 = 1 - w0 - w1;
      if (w0 < -1e-4 || w1 < -1e-4 || w2 < -1e-4) continue;
      const d = w0 * P[0][2] + w1 * P[1][2] + w2 * P[2][2], k = y * w + x;
      if (d >= Z[k]) continue;
      Z[k] = d; T[k] = glow ? 2 : lum * lit; ID[k] = ti >> 1;
    }
  });
  // sepia shading with hatched darks, outlines at silhouette and face/depth breaks
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(w, h), px = img.data;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const k = y * w + x;
    if (T[k] < 0) continue;
    const o = k * 4;
    let edge = false;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= w || ny >= h) { edge = true; break; }
      const n = ny * w + nx;
      if (T[n] < 0 || Math.abs(Z[n] - Z[k]) > 1.2) { edge = true; break; }
    }
    if (edge) { px[o] = 58; px[o + 1] = 38; px[o + 2] = 22; px[o + 3] = 235; continue; }
    if (T[k] === 2) { px[o] = 196; px[o + 1] = 120; px[o + 2] = 40; px[o + 3] = 220; continue; }   // glowing bits in red-brown ink
    const t = Math.max(0, Math.min(1, T[k]));
    const hatch = t < 0.35 && ((x + y) % 3 === 0) ? 0.6 : t < 0.55 && ((x - y) % 4 === 0) ? 0.8 : 1;
    const ink = (1 - t) * 0.85;
    px[o] = 90; px[o + 1] = 62; px[o + 2] = 36;
    px[o + 3] = Math.round(255 * Math.min(0.9, (ink * 0.9 + 0.08) / hatch * (hatch < 1 ? 1.3 : 1)));
  }
  ctx.putImageData(img, 0, 0);
  const url = cv.toDataURL();
  if (key) CACHE.set(key, url);
  return url;
}
