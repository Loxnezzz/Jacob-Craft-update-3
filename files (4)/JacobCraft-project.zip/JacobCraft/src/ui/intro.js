// New-world screens: pick your adventurer, then a short illustrated story that sets up what the game is about.
// The intro is drawn on a low-resolution canvas (chunky pixels, like the blocks) with the words typed out over it.
import { CHARACTERS, CHARACTER_IDS, cleanName } from '../game/characters.js';
import { drawPlayerPortrait } from '../game/playerModel.js';

const el = (tag, cls, parent, html) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  if (parent) parent.appendChild(e);
  return e;
};
const NO_ARMOR = { armor: { slots: [null, null, null, null] } };

// ======================================================================= character creator
// Name your adventurer, start from one of the five presets and change anything: skin, hair, eyes, facial hair,
// shirt, sleeves, trousers, shoes and build. The preview turns as you drag it.
const SKINS = ['#f6dcc6', '#f0c8b0', '#e8b896', '#d8a07a', '#c8956c', '#a8764e', '#8a5a3a', '#7a4e32', '#5e3a24', '#3e261a'];
const HAIR_STYLES = [['short', 'Short'], ['messy', 'Messy'], ['curly', 'Curly'], ['long', 'Long'], ['ponytail', 'Ponytail'], ['bun', 'Bun'], ['braids', 'Braids'], ['bald', 'Bald']];
const HAIR_COLS = ['#141218', '#2c1b10', '#3b2516', '#6a4226', '#a0682e', '#c0602a', '#e0c070', '#d8dce8', '#8a2a3a', '#3a5ab8', '#4a8a3a', '#d86a9a'];
const EYES = ['#2a1e18', '#3a2a1e', '#6a4a2a', '#4a5ab8', '#3a8a4a', '#5a7a8a', '#7a4ac8', '#8a2a2a'];
const BEARDS = [['none', 'None'], ['shadow', "5 o'clock"], ['stubble', 'Stubble'], ['goatee', 'Goatee'], ['mustache', 'Mustache'], ['trimmed', 'Trimmed'], ['full', 'Full']];
const SHIRTS = ['#2fa6a6', '#3a5ab8', '#5a8a3a', '#e8c040', '#e0762a', '#c0302a', '#d86a9a', '#6a3a9a', '#e8e8e8', '#8a8a92', '#3a3a42', '#6a4a2e'];
const PANTS = ['#3a46a0', '#2e3440', '#262036', '#4a4a52', '#2a2a2e', '#6a4a2e', '#8a7a5a', '#5a6a3a', '#7a2a2a', '#c8c0b0'];
const SHOES = ['#5a5a5e', '#2a2a30', '#3a2a1e', '#8a4a2a', '#e8e8e8', '#c03030', '#3a5ab8', '#4a3a5a'];
const BUILDS = [['0.92', 'Slim'], ['1', 'Regular'], ['1.08', 'Broad']];

const hx = (h) => { const v = parseInt(h.slice(1), 16); return [(v >> 16) & 255, (v >> 8) & 255, v & 255]; };
const toHex = (c) => '#' + c.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
const shade = (h, k) => toHex(hx(h).map(v => v * k));
const mixc = (a, b, t) => { const A = hx(a), Bc = hx(b); return toHex(A.map((v, i) => v + (Bc[i] - v) * t)); };
const pick = (a) => a[Math.floor(Math.random() * a.length)];

// the editable choices taken out of a full look
function cfgFromLook(L) {
  return {
    skin: L.skin, hairStyle: L.hairStyle || 'short', hair: L.hair, eye: L.eye || '#3a2a1e', beardStyle: L.beardStyle || 'none',
    shirt: L.shirt, rolled: L.rolled !== false, pants: L.pants, boots: L.boots, wide: String(L.wide || 1),
  };
}
// and a full look built back from them (details like blush and freckles come from the preset it started from)
function lookFromCfg(c, base) {
  const L = Object.assign({}, base);
  L.skin = c.skin; L.skinDark = shade(c.skin, 0.84); L.lip = mixc(c.skin, '#8a4a44', 0.55);
  L.hairStyle = c.hairStyle; L.hair = c.hair; L.hair2 = shade(c.hair, 0.75); L.brow = shade(c.hair, 0.72);
  L.eye = c.eye;
  if (c.beardStyle === 'none') { delete L.beardStyle; delete L.beard; }
  else { L.beardStyle = c.beardStyle; L.beard = c.beardStyle === 'shadow' || c.beardStyle === 'stubble' ? mixc(c.hair, c.skin, 0.5) : shade(c.hair, 0.95); }
  if (c.shirt !== base.shirt) { L.shirt = c.shirt; L.shirt2 = shade(c.shirt, 0.86); L.collar = c.shirt; L.sleeve = c.shirt; L.cuff = shade(c.shirt, 0.86); }
  L.rolled = c.rolled;
  L.pants = c.pants; L.pants2 = shade(c.pants, 0.86); L.boots = c.boots;
  L.wide = Number(c.wide); L.headScale = 1;
  return L;
}

export function characterCreator(app, meta, done) {
  const m = app.menus.base(false);
  m.classList.add('charCreate');
  el('div', 'cc-title', m, 'Create Your Adventurer');
  const wrap = el('div', 'cc-wrap', m);
  // ---- preview
  const left = el('div', 'cc-left', wrap);
  // your name, in a box right above your adventurer's head
  const nameRow = el('div', 'cc-name', left);
  const nameIn = el('input', '', nameRow); nameIn.maxLength = 16; nameIn.spellcheck = false; nameIn.placeholder = 'Type your name…';
  const stage = el('div', 'cc-stage', left);
  const cv = el('canvas', '', stage); cv.width = 240; cv.height = 340;
  el('div', 'cc-drag', stage, '⇆ drag to turn');
  // ---- options
  const right = el('div', 'cc-right', wrap);
  let presetId = meta.character && CHARACTERS[meta.character] ? meta.character : 'jacob';
  let base = Object.assign({}, CHARACTERS[presetId].look);
  let cfg = cfgFromLook(meta.look || base);
  nameIn.value = meta.playerName || '';
  nameIn.addEventListener('input', () => { const v = nameIn.value.replace(/[^A-Za-z0-9 '_.-]/g, '').slice(0, 16); if (v !== nameIn.value) nameIn.value = v; });
  nameIn.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.code === 'Enter') go(); });

  const sections = [];
  const section = (title) => { const s = el('div', 'cc-sec', right); el('div', 'cc-h', s, title); const body = el('div', 'cc-opts', s); return body; };
  // a row of colour swatches bound to cfg[key]
  const swatches = (body, key, cols) => {
    const btns = cols.map((c) => { const b = el('button', 'cc-sw', body); b.style.background = c; b.title = c; b.onclick = () => { cfg[key] = c; changed(); }; return [c, b]; });
    sections.push(() => btns.forEach(([c, b]) => b.classList.toggle('on', cfg[key] === c)));
  };
  // a row of word buttons bound to cfg[key]
  const choices = (body, key, opts) => {
    const btns = opts.map(([v, lab]) => { const b = el('button', 'cc-ch', body, lab); b.onclick = () => { cfg[key] = v; changed(); }; return [v, b]; });
    sections.push(() => btns.forEach(([v, b]) => b.classList.toggle('on', String(cfg[key]) === String(v))));
  };

  // presets as small portraits
  const pre = section('Start from');
  pre.classList.add('cc-presets');
  const preBtns = CHARACTER_IDS.map((id) => {
    const b = el('button', 'cc-pre', pre);
    const c = el('canvas', '', b); c.width = 56; c.height = 80;
    drawPlayerPortrait(c, NO_ARMOR, 0.2, 0, id);
    b.onclick = () => {
      presetId = id; base = Object.assign({}, CHARACTERS[id].look); cfg = cfgFromLook(base);
      changed();
    };
    return [id, b];
  });
  sections.push(() => preBtns.forEach(([id, b]) => b.classList.toggle('on', id === presetId)));
  swatches(section('Skin'), 'skin', SKINS);
  const hair = section('Hair');
  choices(hair, 'hairStyle', HAIR_STYLES);
  el('div', 'cc-break', hair);
  swatches(hair, 'hair', HAIR_COLS);
  swatches(section('Eyes'), 'eye', EYES);
  choices(section('Facial hair'), 'beardStyle', BEARDS);
  const shirt = section('Shirt');
  swatches(shirt, 'shirt', SHIRTS);
  el('div', 'cc-break', shirt);
  choices(shirt, 'rolled', [[true, 'Short sleeves'], [false, 'Long sleeves']]);
  swatches(section('Trousers'), 'pants', PANTS);
  swatches(section('Shoes'), 'boots', SHOES);
  choices(section('Build'), 'wide', BUILDS);

  const btns = el('div', 'cc-btns', m);
  const rand = el('button', 'btn', btns, '\u{1F3B2} Randomize');
  rand.onclick = () => {
    presetId = pick(CHARACTER_IDS); base = Object.assign({}, CHARACTERS[presetId].look);
    cfg = { skin: pick(SKINS), hairStyle: pick(HAIR_STYLES)[0], hair: pick(HAIR_COLS), eye: pick(EYES), beardStyle: Math.random() < 0.5 ? 'none' : pick(BEARDS)[0],
      shirt: pick(SHIRTS), rolled: Math.random() < 0.5, pants: pick(PANTS), boots: pick(SHOES), wide: pick(BUILDS)[0] };
    presetId = null;
    changed();
  };
  const begin = el('button', 'btn primary big', btns, 'Begin ▶');
  begin.onclick = () => { app.audio.play('click'); go(); };

  let look = lookFromCfg(cfg, base);
  function changed() {
    look = lookFromCfg(cfg, base);
    // still exactly a preset? (then it is saved as that preset)
    if (presetId && JSON.stringify(cfgFromLook(CHARACTERS[presetId].look)) !== JSON.stringify(cfg)) presetId = null;
    for (const f of sections) f();
    app.audio.play('click');
    dirty = true;
  }
  for (const f of sections) f();

  let alive = true, dirty = true, yaw = 0.5, dragging = false, lastX = 0, spinV = 0;
  const go = () => {
    if (!alive) return;
    const name = cleanName(nameIn.value);
    if (!name) { nameIn.classList.add('bad'); nameIn.focus(); setTimeout(() => nameIn.classList.remove('bad'), 600); return; }
    alive = false;
    clearInterval(timer);
    meta.playerName = name;
    meta.character = presetId || 'custom';
    meta.look = look;
    done(meta.character);
  };
  stage.addEventListener('mousedown', (e) => { dragging = true; lastX = e.clientX; e.preventDefault(); });
  addEventListener('mouseup', () => { dragging = false; });
  addEventListener('mousemove', (e) => { if (!dragging) return; const d = (e.clientX - lastX) * 0.012; yaw += d; spinV = d; lastX = e.clientX; dirty = true; });
  let t = 0;
  const timer = setInterval(() => {   // (a timer rather than rAF: it keeps going in hidden preview panes)
    if (!alive || !m.isConnected) { clearInterval(timer); return; }
    t += 0.05;
    if (!dragging && Math.abs(spinV) > 0.001) { yaw += spinV; spinV *= 0.9; dirty = true; }
    // an idle glance about every few seconds
    const glance = Math.sin(t * 0.7) * 0.25;
    drawPlayerPortrait(cv, NO_ARMOR, glance, Math.sin(t * 0.43) * 0.08, look, { viewYaw: yaw });
    void dirty;
  }, 50);
  setTimeout(() => { if (alive) nameIn.focus(); }, 50);
}

// ======================================================================= the story
const PW = 320, PH = 180;   // the picture is painted at this size and scaled up with hard pixels
const rnd = (a, b) => a + Math.random() * (b - a);
function hash(n) { const x = Math.sin(n * 127.1) * 43758.5453; return x - Math.floor(x); }

// blocky hills: a strip of columns whose height comes from a few sines, drawn as stacked squares
function hills(g, seed, base, amp, col, top, offset = 0, block = 4) {
  for (let x = 0; x < PW + block; x += block) {
    const wx = x + offset;
    const h = base + Math.round((Math.sin(wx * 0.021 + seed) * 0.6 + Math.sin(wx * 0.057 + seed * 2.3) * 0.3 + Math.sin(wx * 0.11 + seed * 5.1) * 0.1) * amp / block) * block;
    g.fillStyle = col; g.fillRect(x, PH - h, block, h);
    if (top) { g.fillStyle = top; g.fillRect(x, PH - h, block, block); }
  }
}
function sky(g, c0, c1, c2) {
  const gr = g.createLinearGradient(0, 0, 0, PH);
  gr.addColorStop(0, c0); gr.addColorStop(0.6, c1); gr.addColorStop(1, c2);
  g.fillStyle = gr; g.fillRect(0, 0, PW, PH);
}
function stars(g, t, n = 90, a = 1) {
  for (let i = 0; i < n; i++) {
    const x = hash(i) * PW, y = hash(i + 50) * PH * 0.7, tw = 0.5 + 0.5 * Math.sin(t * (1 + hash(i + 9) * 3) + i);
    g.fillStyle = `rgba(255,255,240,${(0.35 + tw * 0.65) * a})`;
    g.fillRect(Math.floor(x), Math.floor(y), hash(i + 3) > 0.9 ? 2 : 1, 1);
  }
}
function glow(g, x, y, r, col, a) {
  const gr = g.createRadialGradient(x, y, 0, x, y, r);
  gr.addColorStop(0, col.replace('A', a)); gr.addColorStop(1, col.replace('A', 0));
  g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
}
// the Worldheart: a faceted gem, pulsing; crack > 0 dims and splits it
function heart(g, x, y, s, t, crack = 0) {
  const beat = 1 + Math.max(0, Math.sin(t * 2.4)) * 0.08 * (1 - crack);
  glow(g, x, y, 46 * s * beat, `rgba(255,120,150,A)`, 0.55 * (1 - crack * 0.8));
  const S = 14 * s * beat;
  const P = (pts, c) => { g.fillStyle = c; g.beginPath(); g.moveTo(x + pts[0][0] * S, y + pts[0][1] * S); for (const p of pts.slice(1)) g.lineTo(x + p[0] * S, y + p[1] * S); g.fill(); };
  const k = 1 - crack * 0.6;
  P([[0, -1.1], [0.9, -0.2], [0, 1.2], [-0.9, -0.2]], `rgb(${200 * k | 0},${40 * k | 0},${80 * k | 0})`);
  P([[0, -1.1], [0.9, -0.2], [0, -0.1]], `rgb(${255 * k | 0},${110 * k | 0},${150 * k | 0})`);
  P([[0, -1.1], [-0.9, -0.2], [0, -0.1]], `rgb(${235 * k | 0},${70 * k | 0},${110 * k | 0})`);
  P([[-0.9, -0.2], [0, -0.1], [0, 1.2]], `rgb(${150 * k | 0},${24 * k | 0},${60 * k | 0})`);
  if (crack > 0) { g.strokeStyle = '#1a0a10'; g.lineWidth = 1; g.beginPath(); g.moveTo(x - 2, y - S); g.lineTo(x + 3, y - 3); g.lineTo(x - 2, y + 4); g.lineTo(x + 1, y + S); g.stroke(); }
}
// pixel silhouettes of the five great beasts (each a list of [x, y, w, h] blocks in 2px units)
const BEASTS = [
  { name: 'The Mammoth', col: '#9ad8ff', eye: '#e8f8ff', boxes: [[0, 6, 16, 9], [2, 15, 3, 6], [11, 15, 3, 6], [-5, 4, 7, 8], [-7, 10, 3, 9], [-9, 17, 4, 2], [3, 3, 10, 3]], ex: -3, ey: 7 },
  { name: 'The Warden', col: '#7ae07a', eye: '#d0ffb0', boxes: [[3, 6, 8, 14], [0, 0, 14, 7], [-3, 2, 4, 3], [13, 1, 4, 3], [1, 20, 4, 3], [9, 20, 4, 3], [-2, 9, 5, 2], [11, 9, 5, 2]], ex: 5, ey: 4 },
  { name: 'The Titan', col: '#ffd060', eye: '#fff4c0', boxes: [[3, 0, 8, 7], [1, 7, 12, 10], [-2, 7, 3, 10], [13, 7, 3, 10], [3, 17, 3, 7], [8, 17, 3, 7]], ex: 5, ey: 3 },
  { name: 'The Wyrm', col: '#c8f0ff', eye: '#ffffff', boxes: [[0, 0, 6, 4], [5, 2, 5, 4], [9, 5, 5, 4], [12, 9, 5, 4], [10, 13, 5, 4], [5, 15, 5, 4], [1, 17, 4, 3], [-3, 1, 4, 2]], ex: 1, ey: 1 },
  { name: 'The Behemoth', col: '#ff7040', eye: '#ffd080', boxes: [[0, 4, 18, 12], [2, 0, 6, 5], [11, 1, 5, 4], [1, 16, 4, 6], [13, 16, 4, 6], [-4, 7, 5, 6]], ex: -2, ey: 9 },
];
function beast(g, B, x, y, lit, t) {
  for (const [bx, by, bw, bh] of B.boxes) { g.fillStyle = '#05060a'; g.fillRect(x + bx * 2, y + by * 2, bw * 2, bh * 2); }
  if (lit > 0) {
    glow(g, x + 14, y + 20, 40, hexA(B.col), 0.35 * lit);
    const blink = Math.sin(t * 3 + x) > -0.95 ? 1 : 0;
    g.fillStyle = B.eye; g.globalAlpha = lit * blink;
    g.fillRect(x + B.ex * 2, y + B.ey * 2, 2, 2); g.fillRect(x + B.ex * 2 + 5, y + B.ey * 2, 2, 2);
    g.globalAlpha = 1;
  }
}
function hexA(h) { const v = parseInt(h.slice(1), 16); return `rgba(${(v >> 16) & 255},${(v >> 8) & 255},${v & 255},A)`; }

export function playIntro(app, meta, done) {
  const who = cleanName(meta.playerName) || (CHARACTERS[meta.character] || CHARACTERS.jacob).name;
  const root = el('div', '', document.body); root.id = 'intro';
  const cv = el('canvas', '', root); cv.width = PW; cv.height = PH;
  const g = cv.getContext('2d'); g.imageSmoothingEnabled = false;
  const bars = el('div', 'bars', root);
  const text = el('div', 'itext', root);
  const hint = el('div', 'ihint', root, 'Click or press Space to continue');
  const skip = el('button', 'iskip', root, 'Skip ▸▸');
  // the chosen adventurer, painted once for the dawn scene
  const hero = document.createElement('canvas'); hero.width = 44; hero.height = 64;
  drawPlayerPortrait(hero, NO_ARMOR, 0.35, -0.05, meta.look || meta.character || 'jacob');
  const embers = Array.from({ length: 40 }, () => ({ x: rnd(0, PW), y: rnd(0, PH), v: rnd(4, 14), s: rnd(0, 6) }));
  const SCENES = [
    { dur: 9, lines: ['Long ago, before the first village and the first fire,', 'the world was held together by five old hearts.'], draw: (t) => {
      sky(g, '#05040f', '#120a2a', '#22123a'); stars(g, t);
      heart(g, PW / 2, 70, 1.3, t);
      const cols = ['#9ad8ff', '#7ae07a', '#ffd060', '#c8f0ff', '#ff7040'];
      for (let i = 0; i < 5; i++) { const a = t * 0.5 + i / 5 * Math.PI * 2; const x = PW / 2 + Math.cos(a) * 48, y = 70 + Math.sin(a) * 18; glow(g, x, y, 10, hexA(cols[i]), 0.8); g.fillStyle = cols[i]; g.fillRect(Math.round(x) - 1, Math.round(y) - 1, 3, 3); }
      hills(g, 1.3, 26, 14, '#0c0818', '#1a1030', t * 2);
    } },
    { dur: 10, lines: ['Five great beasts guarded them:', 'the Mammoth, the Warden, the Titan, the Wyrm and the Behemoth.', 'But their sleep grew restless…'], draw: (t) => {
      sky(g, '#0a1030', '#2a2050', '#5a3050'); stars(g, t, 60, 0.6);
      hills(g, 4.1, 84, 18, '#151530', '#20204a', 0);
      for (let i = 0; i < 5; i++) {
        const x = 18 + i * 60, y = 50 + (i % 2) * 6;
        const lit = Math.min(1, Math.max(0, (t - 0.6 - i * 1.0) * 1.5));
        beast(g, BEASTS[i], x, y, lit, t);
        if (lit > 0) { g.globalAlpha = lit; g.fillStyle = BEASTS[i].col; g.font = '7px monospace'; g.textAlign = 'center'; g.fillText(BEASTS[i].name, x + 14, 116); g.globalAlpha = 1; }
      }
      hills(g, 2.2, 24, 8, '#08081a', null, t * 3);
    } },
    { dur: 9, lines: ['The Worldheart dimmed. Monsters crept up out of the caves,', 'and something began to watch from the dark.'], draw: (t) => {
      sky(g, '#120406', '#2a0a10', '#3a1010');
      heart(g, PW / 2, 46, 0.9, t, Math.min(1, t / 4));
      hills(g, 7.7, 64, 16, '#0a0406', '#160a0c', 0);
      // eyes opening in the dark
      for (let i = 0; i < 14; i++) {
        const open = t - 1 - hash(i) * 6; if (open < 0) continue;
        const x = 10 + hash(i + 20) * (PW - 20), y = 112 + hash(i + 40) * 56, blink = Math.sin(t * 2 + i * 3) > -0.9 ? 1 : 0;
        const c = i % 4 === 0 ? '#d070ff' : i % 3 === 0 ? '#9aff4a' : '#ff3030';
        g.fillStyle = c; g.globalAlpha = Math.min(1, open) * blink;
        g.fillRect(Math.round(x), Math.round(y), 2, 1); g.fillRect(Math.round(x) + 5, Math.round(y), 2, 1);
        g.globalAlpha = 1;
      }
      // the tall thin watcher on the ridge, only for a moment
      if (t > 5 && t < 7.5) { const a = Math.min(1, (t - 5) * 2, (7.5 - t) * 2); g.globalAlpha = a; g.fillStyle = '#000'; g.fillRect(232, 86, 5, 30); g.fillRect(231, 80, 7, 7); g.fillRect(229, 92, 2, 20); g.fillRect(238, 92, 2, 20); g.fillStyle = '#e8e4d8'; g.fillRect(233, 82, 3, 4); g.globalAlpha = 1; }
      for (const e of embers) { e.y -= e.v * 0.016; if (e.y < 0) { e.y = PH; e.x = rnd(0, PW); } g.fillStyle = 'rgba(255,90,40,0.6)'; g.fillRect(Math.round(e.x + Math.sin(t + e.s) * 3), Math.round(e.y), 1, 1); }
    } },
    { dur: 9, lines: [`Then ${who} washed up on these shores, with nothing but`, 'two empty hands and a very stubborn heart.'], draw: (t) => {
      const k = Math.min(1, t / 6);
      sky(g, k > 0.5 ? '#4a7ad0' : '#2a2a60', '#e89a6a', '#ffd890');
      const sunY = 150 - k * 70;
      glow(g, 240, sunY, 60, 'rgba(255,220,140,A)', 0.8); g.fillStyle = '#fff2c0'; g.fillRect(232, Math.round(sunY) - 8, 16, 16);
      hills(g, 3.3, 70, 20, '#3a6a3a', '#5aa04a', 0);
      g.fillStyle = '#2a6aa8'; g.fillRect(0, PH - 26, PW, 26); g.fillStyle = '#4a8ad0'; for (let x = 0; x < PW; x += 8) g.fillRect((x + Math.round(t * 6)) % PW, PH - 26 + ((x / 8) % 3), 4, 1);
      hills(g, 9.1, 40, 8, '#c8b47a', '#e8d49a', 0);   // the beach
      const hx = 70 + Math.min(1, t / 5) * 30, hy = PH - 40 - 56;
      g.drawImage(hero, Math.round(hx), Math.round(hy), 32, 48);
      // gulls
      for (let i = 0; i < 3; i++) { const x = (40 + i * 70 + t * 12) % PW, y = 30 + i * 9 + Math.sin(t * 3 + i) * 2; g.fillStyle = '#f0f0f0'; g.fillRect(Math.round(x), Math.round(y), 2, 1); g.fillRect(Math.round(x) + 3, Math.round(y), 2, 1); g.fillRect(Math.round(x) + 2, Math.round(y) + 1, 1, 1); }
    } },
    { dur: 13, quest: true, lines: ['Your quest:'], draw: (t) => {
      sky(g, '#1a1424', '#2a1e30', '#3a2830'); stars(g, t, 40, 0.4);
      // a parchment page
      g.fillStyle = '#c8b088'; g.fillRect(40, 18, 240, 144); g.fillStyle = '#e8d8b0'; g.fillRect(44, 22, 232, 136);
    } },
    { dur: 6, title: true, lines: ['Your adventure begins.'], draw: (t) => {
      sky(g, '#7ab0f0', '#a8d0f8', '#e8f0ff');
      glow(g, PW / 2, 70, 90, 'rgba(255,255,255,A)', 0.5);
      hills(g, 5.5, 50, 16, '#4a8a3a', '#6ab04a', t * 4);
      hills(g, 8.2, 28, 8, '#3a6a2a', '#5a9a3a', t * 9);
    } },
  ];
  // little pixel pictures for the quest list (drawn into the text, so they always line up with it)
  const ICONS = [
    (c) => { c.fillStyle = '#6a4a2a'; c.fillRect(7, 5, 3, 11); c.fillStyle = '#7a7a84'; c.fillRect(1, 2, 15, 4); c.fillStyle = '#9a9aa4'; c.fillRect(2, 2, 13, 1); },
    (c) => { c.fillStyle = '#e8c050'; c.fillRect(1, 7, 14, 7); for (const k of [1, 6, 11]) c.fillRect(k, 3, 3, 5); c.fillStyle = '#ff3a6a'; c.fillRect(6, 9, 3, 3); },
    (c) => { c.fillStyle = '#3a3248'; c.fillRect(1, 1, 14, 14); c.fillStyle = '#5a5068'; c.fillRect(2, 2, 12, 1); c.fillStyle = '#40e8d0'; c.fillRect(7, 3, 2, 6); c.fillStyle = '#8a8098'; c.fillRect(7, 9, 2, 4); },
    (c) => { c.fillStyle = '#c83a5a'; c.fillRect(4, 2, 8, 12); c.fillStyle = '#ff7090'; c.fillRect(5, 3, 6, 9); c.fillStyle = '#ffc0d0'; c.fillRect(6, 4, 3, 4); },
  ];
  const QUEST = [
    'Survive your first night: punch trees, craft tools, build a shelter.',
    'Hunt the crowned Champions for their Wayfinder Shards.',
    'Craft a Lair Compass and find the five great beasts.',
    'Forge the Worldheart Keystone and set it on a Runic Altar.',
  ];
  let si = 0, st = 0, alive = true, last = performance.now();
  const chord = (root) => { try { for (const [f, d] of [[1, 0], [1.26, 0.08], [1.5, 0.16]]) app.audio.tone({ f: root * f, dur: 3.2, gain: 0.035, wave: 'triangle', attack: 0.6, delay: d }); } catch (e) { void e; } };
  const ROOTS = [220, 196, 174.6, 261.6, 220, 293.7];
  const show = () => {
    const S = SCENES[si];
    text.innerHTML = '';
    text.className = 'itext' + (S.quest ? ' quest' : '') + (S.title ? ' ititle' : '');
    if (S.title) { const lg = app.menus.logo; if (lg) { const c = lg.cloneNode(); c.getContext('2d').drawImage(lg, 0, 0); text.appendChild(c); } }
    S.lines.forEach((l) => el('div', 'iline', text, '')._full = l);
    if (S.quest) QUEST.forEach((q, i) => {
      const row = el('div', 'iqrow', text);
      const ic = el('canvas', 'iqicon', row); ic.width = 16; ic.height = 16; ICONS[i](ic.getContext('2d'));
      const d = el('div', 'iquest', row, ''); d._full = q; d._delay = 0.8 + i * 1.4; d._row = row;
    });
    if (S.quest) el('div', 'inote', text, 'Press <b>J</b> any time to open your Journal and see what to do next.');
    chord(ROOTS[si]);
  };
  const finish = () => {
    if (!alive) return;
    alive = false;
    clearInterval(timer);
    removeEventListener('keydown', key);
    root.classList.add('out');
    setTimeout(() => { root.remove(); done(); }, 700);
  };
  const next = () => { if (!alive) return; si++; st = 0; if (si >= SCENES.length) finish(); else show(); };
  const key = (e) => { if (e.code === 'Escape') finish(); else if (e.code === 'Space' || e.code === 'Enter') next(); else return; e.preventDefault(); };
  addEventListener('keydown', key);
  root.addEventListener('mousedown', (e) => { if (e.target !== skip) next(); });
  skip.onclick = (e) => { e.stopPropagation(); finish(); };
  show();
  const frame = (now) => {
    if (!alive) return;
    const dt = Math.min(0.1, (now - last) / 1000); last = now;
    st += dt;
    const S = SCENES[si];
    if (st > S.dur) { next(); if (!alive) return; }
    const T = SCENES[si];
    g.save(); T.draw(st); g.restore();
    // fade in/out at the edges of each scene
    const f = Math.min(1, st / 0.8, (T.dur - st) / 0.8);
    if (f < 1) { g.fillStyle = `rgba(0,0,0,${(1 - Math.max(0, f)).toFixed(3)})`; g.fillRect(0, 0, PW, PH); }
    // type the words out
    let tt = st - 0.5;
    for (const d of text.querySelectorAll('.iline, .iquest')) {
      const local = d._delay !== undefined ? st - d._delay : tt;
      const n = Math.max(0, Math.min(d._full.length, Math.floor(local * 38)));
      if (d.textContent.length !== n) d.textContent = d._full.slice(0, n);
      if (d._row) d._row.style.opacity = local > 0 ? 1 : 0;
      if (d._delay === undefined) tt -= d._full.length / 38 + 0.25;
    }
    hint.style.opacity = st > 3 ? 0.7 : 0;
  };
  const timer = setInterval(() => frame(performance.now()), 33);
  void bars;
}
