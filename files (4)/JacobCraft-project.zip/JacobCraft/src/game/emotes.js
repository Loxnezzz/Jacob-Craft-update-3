// Emotes: press B (or the Emote key) for a wheel of eight; pick one and your adventurer acts it out. In first person
// the camera swings round to the front for the length of the emote. Villagers nearby wave back.
export const EMOTES = [
  { id: 'wave', label: 'Wave', icon: '\u{1F44B}', dur: 2.2 },
  { id: 'dance', label: 'Dance', icon: '\u{1F57A}', dur: 4.5 },
  { id: 'cheer', label: 'Cheer', icon: '\u{1F64C}', dur: 2.4 },
  { id: 'clap', label: 'Clap', icon: '\u{1F44F}', dur: 2.4 },
  { id: 'point', label: 'Point', icon: '\u{1F449}', dur: 2.0 },
  { id: 'bow', label: 'Bow', icon: '\u{1F647}', dur: 2.2 },
  { id: 'sit', label: 'Sit', icon: '\u{1FA91}', dur: 6.0 },
  { id: 'laugh', label: 'Laugh', icon: '\u{1F602}', dur: 2.6 },
];

// pose for the third-person model while an emote plays. S(part, pitch, yaw, roll, tx, ty, tz); on this model a
// positive pitch swings a limb forward, and a positive roll lifts the right arm out to the side (negative the left).
export function emotePose(e, S, t) {
  const k = Math.min(1, e.t * 5, (e.dur - e.t) * 5);   // ease in and out
  const T = e.t;
  switch (e.id) {
    case 'wave': S('armR', 0.2 * k, 0, (2.55 + Math.sin(T * 11) * 0.35) * k); S('head', 0, 0, -0.08 * k); break;
    case 'cheer': {
      const b = Math.abs(Math.sin(T * 7));
      S('armR', 0, 0, (2.75 + b * 0.2) * k); S('armL', 0, 0, -(2.75 + b * 0.2) * k);
      S('body', 0, 0, 0, 0, b * 1.2 * k, 0); S('legL', 0, 0, 0, 0, b * 1.2 * k, 0); S('legR', 0, 0, 0, 0, b * 1.2 * k, 0); S('head', -0.25 * k);
      break;
    }
    case 'dance': {
      const beat = T * 6.4, s = Math.sin(beat), c = Math.cos(beat);
      S('body', 0, s * 0.35 * k, c * 0.08 * k, 0, Math.abs(c) * 0.8 * k, 0);
      S('armR', (1.2 + s * 1.2) * k, 0, (0.9 + c * 0.5) * k); S('armL', (1.2 - s * 1.2) * k, 0, -(0.9 - c * 0.5) * k);
      S('legL', s * 0.5 * k, 0, -0.1 * k); S('legR', -s * 0.5 * k, 0, 0.1 * k);
      S('head', Math.abs(s) * 0.2 * k, -s * 0.3 * k, c * 0.15 * k);
      break;
    }
    case 'clap': {
      const c = Math.abs(Math.sin(T * 9));
      S('armR', 1.25 * k, (-0.25 - 0.3 * (1 - c)) * k, 0); S('armL', 1.25 * k, (0.25 + 0.3 * (1 - c)) * k, 0);
      S('head', -0.1 * k);
      break;
    }
    case 'point': S('armR', 1.55 * k, 0.1 * k, 0); S('head', -0.05 * k, 0.1 * k); S('body', 0, 0.15 * k, 0); break;
    case 'bow': S('body', -0.75 * k, 0, 0); S('head', 0.3 * k); S('armR', 0.9 * k, -0.5 * k, 0); S('armL', -0.3 * k, 0, -0.1 * k); break;
    case 'sit': S('legL', 1.5 * k, 0.12 * k, -0.08 * k); S('legR', 1.5 * k, -0.12 * k, 0.08 * k); S('armL', 0.35 * k, 0, -0.15 * k); S('armR', 0.35 * k, 0, 0.15 * k); break;
    case 'laugh': {
      const sh = Math.sin(T * 22) * 0.06;
      S('body', (-0.15 + sh) * k, 0, 0); S('head', (-0.35 + sh * 2) * k);
      S('armR', 0.55 * k, -0.6 * k, 0); S('armL', 0.55 * k, 0.6 * k, 0);
      break;
    }
  }
  void t;
}
// how far the whole body drops (sitting)
export function emoteDrop(e) { return e && e.id === 'sit' ? 0.62 * Math.min(1, e.t * 5, (e.dur - e.t) * 5) : 0; }

export function installEmotes(game) {
  const ui = game.ui;
  game.emote = null;

  game.startEmote = (id) => {
    const E = EMOTES.find(x => x.id === id);
    const p = game.player;
    if (!E || !p || p.dead || p.riding || game.sleeping) return;
    game.emote = { id, t: 0, dur: E.dur, beat: 0, camWas: game.thirdPerson };
    if (game.thirdPerson === 0) game.thirdPerson = 2;   // turn the camera round to watch
    const at = { x: p.x, y: p.y + 1.6, z: p.z };
    const A = game.audio;
    if (id === 'cheer') { A.play('levelup', null, 1.3); burst(p, 'confetti'); }
    else if (id === 'laugh') for (let i = 0; i < 4; i++) A.tone({ f: 420 - i * 30, fEnd: 360 - i * 30, dur: 0.12, gain: 0.08, wave: 'triangle', lp: 1600, delay: i * 0.17 }, at);
    else if (id === 'wave') A.tone({ f: 660, fEnd: 880, dur: 0.18, gain: 0.05, wave: 'sine' }, at);
    else if (id === 'bow') A.play('page', at);
    // villagers who can see you answer a wave or a bow
    if (id === 'wave' || id === 'bow' || id === 'cheer') {
      for (const v of game.entities.list) {
        if (v.kind !== 'villager' || v.dead || v.sleeping) continue;
        if (Math.hypot(v.x - p.x, v.z - p.z) > 12 || !v.canSee(p)) continue;
        v.waveBackT = 2.2 + Math.random() * 0.6; v.lookAt = p;
      }
    }
  };
  const stop = () => {
    const e = game.emote;
    if (!e) return;
    if (e.camWas === 0 && game.thirdPerson === 2) game.thirdPerson = 0;
    game.emote = null;
  };
  game.stopEmote = stop;

  function burst(p, kind) {
    const P = game.particles;
    const cols = [[1, 0.3, 0.3], [1, 0.85, 0.2], [0.3, 0.9, 0.4], [0.3, 0.6, 1], [0.9, 0.4, 1]];
    for (let i = 0; i < 26; i++) {
      const c = cols[i % cols.length];
      P.add({ x: p.x + (Math.random() - 0.5) * 0.6, y: p.y + 2.1, z: p.z + (Math.random() - 0.5) * 0.6, vx: (Math.random() - 0.5) * 4, vy: 3 + Math.random() * 3, vz: (Math.random() - 0.5) * 4, size: 0.07, r: c[0], g: c[1], b: c[2], a: 1, a0: 1, fade: true, layer: -2, life: 1.6, grav: 7, drag: 1.2, emis: 0.6 });
    }
  }
  function notes(p) {
    const P = game.particles;
    P.add({ x: p.x + (Math.random() - 0.5) * 0.8, y: p.y + 2.0, z: p.z + (Math.random() - 0.5) * 0.8, vx: (Math.random() - 0.5) * 0.4, vy: 0.9, vz: (Math.random() - 0.5) * 0.4, size: 0.14, r: Math.random(), g: 0.6 + Math.random() * 0.4, b: 1, a: 1, a0: 1, fade: true, layer: -2, life: 1.4, emis: 2, add: true });
  }

  // ---- the wheel
  ui.openEmotes = () => {
    ui.openScreen('emotes', (root) => {
      const w = document.createElement('div'); w.className = 'emoteWheel'; root.appendChild(w);
      const mid = document.createElement('div'); mid.className = 'ewMid'; mid.textContent = 'Emotes'; w.appendChild(mid);
      EMOTES.forEach((E, i) => {
        const a = i / EMOTES.length * Math.PI * 2 - Math.PI / 2;
        const b = document.createElement('button'); b.className = 'ewBtn';
        b.style.left = `calc(50% + ${Math.cos(a) * 146}px)`; b.style.top = `calc(50% + ${Math.sin(a) * 146}px)`;
        b.innerHTML = `<span class="ewIco">${E.icon}</span><span>${E.label}</span><small>${i + 1}</small>`;
        b.onmousedown = (ev) => { ev.stopPropagation(); ui.closeScreen(); game.startEmote(E.id); };
        b.onmouseenter = () => { mid.textContent = E.label; };
        w.appendChild(b);
      });
      const hint = document.createElement('div'); hint.className = 'ewHint'; hint.textContent = 'Click an emote, or press 1–8'; root.appendChild(hint);
    });
  };
  addEventListener('keydown', (e) => {
    if (ui.screen !== 'emotes') return;
    const m = /^Digit([1-8])$/.exec(e.code);
    if (m) { e.preventDefault(); ui.closeScreen(); game.startEmote(EMOTES[+m[1] - 1].id); }
    else if (e.code === game.input.binds.emote) { e.preventDefault(); ui.closeScreen(); }
  });

  const prev = game.extUpdate;
  game.extUpdate = (dt) => {
    if (prev) prev(dt);
    const p = game.player, input = game.input;
    if (!p) return;
    const active = game.state === 'playing' && !ui.isOpen && !ui.chatOpen && !p.dead && (input.locked || game.debugActive);
    if (active && input.was('emote') && ui.openEmotes) { ui.openEmotes(); input.unlock(); }
    // villagers waving back
    for (const v of game.entities.list) if (v.waveBackT > 0) v.waveBackT -= dt;
    const e = game.emote;
    if (!e) return;
    e.t += dt;
    // moving, attacking or getting hurt ends it
    const moving = ['forward', 'back', 'left', 'right', 'jump'].some(k => input.down.has(input.binds[k]));
    if (e.t > e.dur || p.dead || p.riding || (moving && e.t > 0.25) || p.swing > 0 || p.hurtTime > 0) { stop(); return; }
    if (e.id === 'dance' && Math.floor(e.t * 3.2) !== e.beat) { e.beat = Math.floor(e.t * 3.2); notes(p); if (e.beat % 2 === 0) game.audio.tone({ f: [523, 659, 784, 659][e.beat / 2 % 4], dur: 0.16, gain: 0.04, wave: 'triangle' }, { x: p.x, y: p.y + 1, z: p.z }); }
    if (e.id === 'clap' && Math.floor(e.t * 2.9) !== e.beat) { e.beat = Math.floor(e.t * 2.9); game.audio.noise({ f: 1800, q: 1.2, dur: 0.05, gain: 0.25 }, { x: p.x, y: p.y + 1.2, z: p.z }); }
    if (e.id === 'cheer' && Math.random() < dt * 2) burst(p, 'confetti');
  };
}
