// The adventurers you can play as. Each is a look for the shared person builder (mobs/people.js); the chosen one is
// stored with the world (meta.character) and used for the third-person model, the inventory portrait and the
// first-person arms.
export const CHARACTERS = {
  jacob: {
    name: 'Jacob', blurb: 'The classic blocky adventurer. Teal tee, blue jeans, five o’clock shadow.',
    look: {
      skin: '#c8956c', skinDark: '#a87a56', hair: '#3b2516', hair2: '#2c1b10', hairStyle: 'short',
      beard: '#a5826a', beardStyle: 'shadow', eye: '#4a5ab8', brow: '#2c1b10', lip: '#8a5a4a',
      shirt: '#2fa6a6', shirt2: '#289090', collar: '#2fa6a6', sleeve: '#2fa6a6', cuff: '#289090', rolled: true,
      pants: '#3a46a0', pants2: '#313b8a', boots: '#5a5a5e', wide: 1, headScale: 1,
    },
  },
  ava: {
    name: 'Ava', blurb: 'A fearless ranger with a copper ponytail and a forest-green tunic.',
    look: {
      skin: '#e8b896', skinDark: '#c8987a', hair: '#c0602a', hair2: '#9a4a1e', hairStyle: 'ponytail',
      eye: '#3a8a4a', brow: '#8a3e18', lip: '#b86a5a', blush: '#e89a8a', freckles: '#b8704a',
      shirt: '#5a8a3a', shirt2: '#4a7430', collar: '#5a8a3a', sleeve: '#5a8a3a', cuff: '#4a7430', rolled: true,
      pants: '#6a4a2e', pants2: '#5a3e26', boots: '#3a2a1e', wide: 0.95, headScale: 1,
    },
  },
  marcus: {
    name: 'Marcus', blurb: 'A cheerful builder in an orange hoodie who never runs out of ideas.',
    look: {
      skin: '#7a4e32', skinDark: '#5e3a24', hair: '#1a1210', hair2: '#120c0a', hairStyle: 'curly',
      beard: '#1a1210', beardStyle: 'goatee', eye: '#3a2a1e', brow: '#120c0a', lip: '#5a3226',
      shirt: '#e0762a', shirt2: '#c06020', collar: '#e0762a', sleeve: '#e0762a', cuff: '#c06020', rolled: false,
      pants: '#4a4a52', pants2: '#3e3e46', boots: '#e8e8e8', wide: 1.05, headScale: 1,
    },
  },
  kenji: {
    name: 'Kenji', blurb: 'A quick-footed explorer in a red jacket, always first into the caves.',
    look: {
      skin: '#e2b48c', skinDark: '#c4966e', hair: '#141218', hair2: '#0c0a10', hairStyle: 'messy',
      eye: '#2a1e18', brow: '#0c0a10', lip: '#a8645a',
      shirt: '#c0302a', shirt2: '#a02822', collar: '#f0f0f0', sleeve: '#c0302a', cuff: '#a02822', rolled: false,
      pants: '#2e3440', pants2: '#262b36', boots: '#2a2a30', wide: 1, headScale: 1,
    },
  },
  luna: {
    name: 'Luna', blurb: 'A stargazing mage-to-be with silver hair and a violet coat.',
    look: {
      skin: '#f0c8b0', skinDark: '#d0a890', hair: '#d8dce8', hair2: '#b0b4c8', hairStyle: 'long',
      eye: '#7a4ac8', brow: '#a0a4b8', lip: '#c07a8a', blush: '#f0a8b0',
      shirt: '#6a3a9a', shirt2: '#57307e', collar: '#e8c860', sleeve: '#6a3a9a', cuff: '#e8c860', rolled: false,
      pants: '#2e2840', pants2: '#262036', boots: '#4a3a5a', wide: 0.95, headScale: 1,
    },
  },
};
export const CHARACTER_IDS = Object.keys(CHARACTERS);

export function characterLook(id) { return (CHARACTERS[id] || CHARACTERS.jacob).look; }
// a preset id or a look object (from the character creator) -> a look
export function resolveLook(x) { return x && typeof x === 'object' ? x : characterLook(x); }
// player names are kept to plain characters so they can go anywhere in the interface safely
export function cleanName(s) { return String(s || '').replace(/[^A-Za-z0-9 '_.-]/g, '').replace(/\s+/g, ' ').trim().slice(0, 16); }

const hex = (h) => { const v = parseInt(h.slice(1), 16); return [((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255]; };
// colours for the first-person arms
export function armColors(id) {
  const L = resolveLook(id);
  const skin = hex(L.skin), skin2 = hex(L.skinDark || L.skin);
  return {
    skin, skin2, skinHi: skin.map(c => Math.min(1, c * 1.08)),
    sleeve: hex(L.sleeve || L.shirt), sleeve2: hex(L.shirt2 || L.shirt), cuff: hex(L.cuff || L.shirt2 || L.shirt), cuff2: hex(L.shirt2 || L.shirt).map(c => c * 0.88),
    // rolled sleeves show the forearm; long sleeves cover the arm down to the wrist
    bare: L.rolled !== false,
  };
}
