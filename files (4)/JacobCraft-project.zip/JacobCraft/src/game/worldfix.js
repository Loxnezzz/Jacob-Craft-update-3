// One-off repairs for worlds saved by older versions of the generator.
// Village houses: older builds could lose a roof (or a row of eaves) to a neighbour's clearing pass. When a saved
// chunk next to a village loads for the first time since this update, any roof block the plan says should be there
// and is open air gets put back. Each chunk is patched once, so a roof the player takes apart later stays apart.
import { villageRoofCells } from '../world/structures.js';
import { B } from '../world/blocks.js';

export function installWorldFixes(game) {
  const prev = game.onStructures;
  game.onStructures = (c, fresh) => {
    if (prev) prev(c, fresh);
    if (!c.restored || !game.mainGen || !game.meta) return;
    const done = game.meta.roofFixed = game.meta.roofFixed || [];
    if (done.includes(c.key)) return;
    let cells;
    try { cells = villageRoofCells(game.mainGen, c.cx, c.cz); } catch (e) { console.warn('roof repair', e); return; }
    if (!cells.length) return;
    done.push(c.key);
    if (done.length > 4000) done.splice(0, done.length - 4000);
    const w = game.world;
    let n = 0;
    for (const [x, y, z, id, m] of cells) {
      const cur = w.getBlock(x, y, z);
      if (cur !== 0 && cur !== B.snow_layer) continue;
      w.setBlock(x, y, z, id, m);
      n++;
    }
    if (n && game.debugRoofs) console.log('roof repair', c.key, n);
  };
}
