// Jacob's Journal as an adventure notebook: an open book of ruled paper with ribbon tabs.
//   Journey    milestones, ticked off in ink, and the road's statistics
//   Bestiary   every creature you have met, sketched in ink, with a note and how many you've bested
//   Atlas      the lands you have walked and the places you have found
//   Beasts     the five great beasts, the champions and the other bosses; the road to the Worldheart
//   Recipes    the useful things you have learned to make
//   Notes      your own notes, kept with the world
import { ITEMS } from './items.js';
import { MOBS } from '../mobs/defs.js';
import { BIOMES } from '../world/biomes.js';
import { RECIPES, recipeIngredients } from './recipes.js';
import { BEASTS, MILESTONES } from './journey.js';
import { BLESSINGS } from './milestones.js';
import { sketchModel } from '../gfx/sketch.js';

const el = (tag, cls, parent, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; if (parent) parent.appendChild(e); return e; };
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (n) => Math.round(n || 0).toLocaleString('en-US');

const LORE = {
  cow: 'Placid, milky, and fond of wheat.', pig: 'Will follow anyone holding a carrot.', sheep: 'Shear for wool; it grows back on grass.',
  chicken: 'Leaves feathers about. Falls gently.', horse: 'Tame by riding until it stops bucking. Hold Space to gather a jump.',
  camel: 'Slow to start, tireless on sand. Can be saddled.', rabbit: 'Quick and shy.', deer: 'Bolts at the first sound of running feet.',
  wolf: 'Tame with bones. A tame wolf guards you fiercely.', cat: 'Tame with fish. Sits, washes, and purrs if you stay close.',
  fox: 'Pounces on things in the grass that I never see.', arctic_fox: 'White as the snow it hunts in.', snow_yak: 'Shaggy and patient.',
  capybara: 'Unbothered by anything.', toucan: 'Mostly beak.', parrot: 'Loud, bright, and nosy.', penguin: 'Walks badly, swims beautifully.',
  monkey: 'Steals fruit. Laughs about it.', frog: 'Sings the swamp to sleep.', fish: 'Good eating, cooked.', bat: 'Lives in the dark under everything.',
  songbird: 'Sings at dawn, flutters off if I come close.', owl: 'Watches from the pines at night. Turns its head right round.',
  vulture: 'Circles the desert, waiting.', eagle: 'Rides the wind over the peaks.', goat: 'Climbs anything. Rams if annoyed.',
  lynx: 'Shy by day. At night, keep your distance.', tapir: 'Like a pig that met an elephant.', lizard: 'Gone before you see it.',
  snow_hare: 'White in the snow, hard to spot.', glimmerstag: 'A white stag whose antlers glow. I only saw it once.',
  dolphin: 'Races alongside boats and leaps for joy.', shark: 'Stay out of deep water.', jellyfish: 'Glows in the dark water. Stings.',
  lanternfish: 'A tiny light in the deep.', magma_beetle: 'Glowing shell, harmless, warm.', dragonfly: 'Darts over still water.',
  shambler: 'The dead walk at night and burn at dawn.', gloomstalker: 'Do not meet its eyes. If you do, be ready.',
  cave_crawler: 'Leaps from the dark. Poisonous bite.', thornling: 'Shoots thorns from the trees.', mire_lurker: 'Waits in the bog.',
  dune_scorpion: 'Its sting poisons. Rare, thankfully.', frost_wraith: 'Throws ice. Hovers over the snow.', ember_fiend: 'Throws fire from the air.',
  jaguar: 'A shadow in the jungle.', moss_golem: 'Slow and mossy, but hits like a landslide.', rootling: 'Little root-creatures. Annoying.',
  frostfang: 'A white wolf whose bite freezes.', cinder_hound: 'Its bite sets you alight.', bog_wisp: 'A cold green light. Don\'t follow it.',
  scarab: 'Pours out of the tomb sand.', wickwalker: 'A tall figure with a porcelain mask and a dead lantern. It watches. When I came close it came apart into moths.',
  villager: 'Friendly folk with trades, gossip and the odd job.', wizard: 'Strange, old and full of errands.', hearthwarden: 'The village guardian, a hearth-fire burning in its chest.',
};
const BOSSES = [['husk_king', 'Ankhuret, the Gilded Husk', 'Sleeps in the tomb beneath the Sunken Pyramid.']];

export function installNotebook(game) {
  const ui = game.ui;
  let tab = 'journey';
  ui.openJournal = () => {
    const J = game.journeyEnsure ? game.journeyEnsure() : (game.player.journey || {});
    if (game.journeyCheck) game.journeyCheck(false);
    game.audio.play('chest_open');
    ui.openScreen('journal', (root) => {
      const book = el('div', 'notebook', root);
      const ribbons = el('div', 'ribbons', book);
      const spread = el('div', 'spread', book);
      const left = el('div', 'page left', spread), right = el('div', 'page right', spread);
      const TABS = [['journey', 'Journey'], ['bestiary', 'Bestiary'], ['atlas', 'Atlas'], ['beasts', 'Beasts'], ['recipes', 'Recipes'], ['notes', 'Notes']];
      const draw = () => {
        left.innerHTML = ''; right.innerHTML = '';
        [...ribbons.children].forEach(r => r.classList.toggle('on', r.dataset.k === tab));
        PAGES[tab](left, right, J);
        game.audio.play('page');
      };
      TABS.forEach(([k, lab], i) => {
        const r = el('button', 'ribbon r' + i, ribbons, lab); r.dataset.k = k;
        r.addEventListener('mousedown', (e) => { e.stopPropagation(); tab = k; draw(); });
      });
      draw();
    });
  };

  const PAGES = {
    journey(L, R, J) {
      el('h2', '', L, `${game.playerName || 'Jacob'}'s Journal`);
      const S = J.stats || {};
      el('p', 'hand', L, `Day ${fmt(game.day)} of the journey.`);
      const st = el('div', 'stats', L);
      for (const [a, b] of [['Travelled', ((S.dist || 0) / 1000).toFixed(1) + ' km'], ['Blocks mined', fmt(S.mined)], ['Blocks placed', fmt(S.placed)], ['Creatures bested', fmt(S.killed)], ['Places found', fmt(S.places)], ['Creatures met', fmt(Object.keys(J.creatures || {}).length)], ['Deaths', fmt(S.deaths)]]) { const r = el('div', 'stat', st); el('span', '', r, a); el('b', '', r, b); }
      el('p', 'margin', L, 'Press J to open this book. Tabs on the right.');
      const nDone = MILESTONES.filter(m => J.done && J.done[m.id]).length;
      el('h3', '', R, `Milestones <small>${nDone} / ${MILESTONES.length}</small>`);
      const list = el('div', 'checklist', R);
      for (const m of MILESTONES) {
        const d = J.done && J.done[m.id];
        const r = el('div', 'check' + (d ? ' done' : ''), list);
        el('i', '', r, d ? '&#10003;' : '');
        el('b', '', r, esc(m.title));
        el('span', '', r, esc(m.desc));
      }
    },
    bestiary(L, R, J) {
      const met = Object.keys(J.creatures || {}).filter(k => MOBS[k] && MOBS[k].type !== 'boss').sort((a, b) => J.creatures[a] - J.creatures[b]);
      const total = Object.keys(MOBS).filter(k => MOBS[k].type !== 'boss' && !k.includes('_jungle') && !(MOBS[k].type === 'watcher')).length;
      el('h2', '', L, 'Bestiary'); el('p', 'hand', L, `${met.length} creatures met (of ${total} known to walk these lands).`);
      if (!met.length) { el('p', 'margin', L, 'Nothing yet. Go and look around.'); return; }
      const all = met.map(k => {
        const d = MOBS[k];
        const c = document.createElement('div'); c.className = 'entry';
        const img = el('img', 'sketch', c); img.src = sketchModel(d.model, 150, 96, 'sk:' + k);
        const t = el('div', 'etext', c);
        el('h4', '', t, esc(d.name));
        el('p', 'hand', t, esc(LORE[k] || `First seen in the ${J.where && J.where[k] ? J.where[k] : 'wild'}.`));
        const n = (J.kills || {})[k];
        el('small', '', t, `${J.where && J.where[k] ? 'Found: ' + esc(J.where[k]) : ''}${n ? ` · bested ${n}` : ''}`);
        return c;
      });
      const half = Math.ceil(all.length / 2);
      const lc = el('div', 'entries', L), rc = el('div', 'entries', R);
      all.forEach((c, i) => (i < half ? lc : rc).appendChild(c));
    },
    atlas(L, R, J) {
      el('h2', '', L, 'Atlas');
      const seen = Object.keys(J.biomes || {}).map(Number).filter(i => BIOMES[i]);
      el('p', 'hand', L, `${seen.length} of ${BIOMES.filter(Boolean).length} lands walked.`);
      const ul = el('div', 'tags', L);
      for (const b of BIOMES) if (b) el('span', 'tag' + (seen.includes(b.id) ? ' on' : ''), ul, seen.includes(b.id) ? esc(b.label) : '?');
      el('h3', '', R, 'Places found');
      const found = Object.keys(J.found || {});
      const NAMES = { ruin: 'Crumbling Ruins', ancient_ruin: 'Ancient Ruins', mineshaft: 'Abandoned Mineshaft', shipwreck: 'Shipwreck', wizard_tower: 'Wizard Tower', dragon_roost: 'Dragon Roost', pyramid: 'The Sunken Pyramid' };
      const counts = {};
      for (const k of found) { const t = k.split(':')[0]; counts[t] = (counts[t] || 0) + 1; }
      if (!found.length) el('p', 'margin', R, 'None yet. Ruins, wrecks and towers are out there somewhere.');
      for (const [t, n] of Object.entries(counts)) el('p', 'hand', R, `${esc(NAMES[t] || t)}${n > 1 ? ` &times; ${n}` : ''}`);
      if (J.creatures && J.creatures.wickwalker) el('p', 'margin red', R, 'Something walks the edges of the light. I have seen it. It has seen me.');
    },
    beasts(L, R, J) {
      const bl = game.player.blessings || [];
      el('h2', '', L, 'The Five Great Beasts');
      for (const b of BEASTS) {
        const done = bl.includes(b.kind);
        const c = el('div', 'beast' + (done ? ' done' : ''), L);
        const d = MOBS[b.kind];
        if (d && J.creatures && J.creatures[b.kind]) { const img = el('img', 'sketch small', c); img.src = sketchModel(d.model, 90, 60, 'sk:' + b.kind); }
        el('b', '', c, esc(b.name) + (done ? ' &mdash; <em>defeated</em>' : ''));
        el('span', 'hand', c, done ? esc(`${BLESSINGS[b.kind].name}: ${BLESSINGS[b.kind].text}`) : esc(b.hint));
      }
      el('h3', '', R, 'The Worldheart');
      const steps = [
        ['Defeat crowned champions for Wayfinder Shards', (J.elites || []).length > 0],
        ['Craft a Lair Compass (Compass + 2 Wayfinder Shards)', !!(J.seen && J.seen.lair_compass)],
        ['Defeat all five great beasts', BEASTS.every(b => bl.includes(b.kind))],
        ['Forge the Worldheart Keystone', !!(J.seen && J.seen.worldheart_keystone)],
        ['Use the Keystone on a Runic Altar', !!J.ending],
      ];
      const sl = el('div', 'checklist', R);
      steps.forEach(([t, d], i) => { const r = el('div', 'check' + (d ? ' done' : ''), sl); el('i', '', r, d ? '&#10003;' : String(i + 1)); el('span', '', r, esc(t)); });
      el('h3', '', R, 'Other foes of note');
      for (const [k, name, hint] of BOSSES) {
        const done = !!(J.flags && J.flags.huskKing) && k === 'husk_king';
        el('p', 'hand' + (done ? ' struck' : ''), R, `${esc(name)}${done ? ' &mdash; defeated' : ''}<br><small>${esc(hint)}</small>`);
      }
      if ((J.elites || []).length) {
        const names = {}; for (const k of J.elites) names[k] = (names[k] || 0) + 1;
        el('p', 'margin', R, 'Champions bested: ' + Object.entries(names).map(([k, n]) => `${esc(MOBS[k] ? MOBS[k].name : k)}${n > 1 ? ' &times;' + n : ''}`).join(', '));
      }
    },
    recipes(L, R, J) {
      void J;
      el('h2', '', L, 'Recipes worth remembering');
      const seen = new Set(), list = [];
      for (const r of RECIPES) {
        const it = ITEMS[r.result];
        if (seen.has(r.result) || !(game.recipeUnlocked ? game.recipeUnlocked(r) : true)) continue;
        if (!(it.tool || it.armor || it.rare || ['basic', 'magic', 'combat', 'storage'].includes(r.group) || it.block >= 0 && ITEMS[r.result].label.match(/Lantern|Bed|Hearth|Brazier|Sconce|Lamp|Shelf|Sign|Chimney|Table|Chair/))) continue;
        seen.add(r.result); list.push(r);
      }
      el('p', 'hand', L, list.length ? `${list.length} worth writing down so far.` : 'Nothing yet. Hold new materials and recipes reveal themselves.');
      const half = Math.ceil(list.length / 2);
      list.slice(0, 60).forEach((r, i) => {
        const row = el('div', 'recipe', i < Math.min(half, 30) ? L : R);
        const im = el('img', '', row); im.src = ui.icon(r.result);
        const t = el('div', '', row);
        el('b', '', t, esc(ITEMS[r.result].label) + (r.count > 1 ? ` &times;${r.count}` : ''));
        el('small', '', t, [...recipeIngredients(r)].map(([ing, n]) => `${n} ${esc(ing.startsWith('#') ? 'any ' + ing.slice(1) : (ITEMS.find(x => x && x.name === ing) || { label: ing }).label)}`).join(', '));
      });
    },
    notes(L, R, J) {
      el('h2', '', L, 'Notes');
      el('p', 'margin', L, 'Write anything here: where you left your gear, the way back to a village, what to try next. Saved with this world.');
      const ta = el('textarea', 'notes', R);
      ta.value = J.notes || '';
      ta.placeholder = 'Dear diary...';
      ta.addEventListener('focus', () => { game.input.textFocus = true; });
      ta.addEventListener('blur', () => { game.input.textFocus = false; J.notes = ta.value.slice(0, 4000); });
      ta.addEventListener('input', () => { J.notes = ta.value.slice(0, 4000); });
      ta.addEventListener('keydown', (e) => e.stopPropagation());
      ta.addEventListener('mousedown', (e) => e.stopPropagation());
    },
  };
}
