// The caves update: creepers and skeletons, monster spawners, and the Broodmother's den.
//
// Creeper   a quiet, mottled green thing on four stubby legs. It walks right up to you, hisses, swells and flashes,
//           and blows a crater in the ground. Step away while it hisses and it calms down.
// Skeleton  a rattling archer that keeps its distance, draws and looses arrows, and burns in the morning sun.
// Spawners  black iron cages left in dungeons, mineshafts and the den. While you are near one it keeps calling up
//           its monsters until there are a few about; break it to stop it.
// The den   a vast cavern deep underground where the Broodmother waits. Walk into it and she drops from the dark.
import { Mob, MOB_CLASSES, createMob } from './mobs.js';
import { MOBS, NIGHT_SPAWNS, CAVE_SPAWNS } from './defs.js';
import { MODELS, PAT, box, part, finalize, humanoid } from './models.js';
import { ANIMS } from './anim.js';
import { B, BLOCKS, IS_LIQUID } from '../world/blocks.js';

const set = (m, P, name, rx = 0, ry = 0, rz = 0, tx = 0, ty = 0, tz = 0) => {
  const i = m.model.index[name];
  if (i === undefined) return;
  const p = P[i];
  p[0] += rx; p[1] += ry; p[2] += rz; p[3] += tx; p[4] += ty; p[5] += tz;
};
const rnd = (a, b) => a + Math.random() * (b - a);

// ===================================================================== creeper
{
  const G1 = '#4d9a3a', G2 = '#2f6e24', FACE = '#0d120c';
  const body = [box([-4, 0, -2], [8, 12, 4], G1, PAT.spots, G2, 3)];
  const head = [
    box([-4, 0, -4], [8, 8, 8], G1, PAT.spots, G2, 3),
    // the face: two square eyes and the long frown
    box([-3, 4, -4.08], [2, 2, 0.12], FACE, PAT.flat), box([1, 4, -4.08], [2, 2, 0.12], FACE, PAT.flat),
    box([-1, 1, -4.08], [2, 3, 0.12], FACE, PAT.flat), box([-2, 0, -4.08], [1, 2.5, 0.12], FACE, PAT.flat), box([1, 0, -4.08], [1, 2.5, 0.12], FACE, PAT.flat),
  ];
  const leg = () => [box([-2, -6, -2], [4, 6, 4], G1, PAT.spots, G2, 3)];
  MODELS.creeper = finalize({
    anim: 'creeper', height: 26,
    parts: [
      part('body', null, [0, 6, 0], body),
      part('head', 'body', [0, 18, 0], head),
      part('legFL', null, [-2, 6, -4], leg()), part('legFR', null, [2, 6, -4], leg()),
      part('legBL', null, [-2, 6, 4], leg()), part('legBR', null, [2, 6, 4], leg()),
    ],
  });
}
MOBS.creeper = Object.assign({}, MOBS.shambler, {
  id: 'creeper', name: 'Creeper', type: 'hostile', hp: 20, speed: 2.3, runSpeed: 2.3, size: [0.6, 1.65], model: MODELS.creeper,
  drops: [['gunpowder', 0, 2], ['niter', 0, 1, 0.25]], sounds: { hurt: 'rustle', death: 'rustle' }, idleSound: 0,
  attack: null, burnsInDay: false, xp: 5, follow: 18,
});
ANIMS.creeper = (m, P) => {
  const s = Math.sin(m.walkPhase * 1.4) * m.walkAmt * 0.7;
  set(m, P, 'legFL', s); set(m, P, 'legBR', s); set(m, P, 'legFR', -s); set(m, P, 'legBL', -s);
  set(m, P, 'head', m.headPitch * 0.6, m.headYaw);
  set(m, P, 'body', 0, 0, 0, 0, -(m.fuse || 0) * 0.6);
};

class Creeper extends Mob {
  constructor(game, kind, x, y, z, opts) { super(game, kind, x, y, z, opts); this.fuse = 0; this.hissing = false; }
  brainHostile(dt) {
    super.brainHostile(dt);
    const g = this.game, t = this.target;
    const close = t && !t.dead && this.distTo(t.x, t.y, t.z) < 3.2 && this.canSee(t);
    if (close || (this.hissing && t && this.distTo(t.x, t.y, t.z) < 7)) {
      if (!this.hissing) { this.hissing = true; g.audio.play('fuse', this); }
      this.fuse += dt;
      this.mx *= 0.15; this.mz *= 0.15;
    } else {
      this.hissing = false;
      this.fuse = Math.max(0, this.fuse - dt * 1.5);
    }
    if (this.fuse >= 1.5 && this.deathT < 0) {
      this.dead = true;
      g.explode(this.x, this.y + 0.8, this.z, this.charged ? 5 : 3, { source: this });
    }
  }
  update(dt) {
    super.update(dt);
    const k = Math.min(1, this.fuse / 1.5);
    this.renderScale = 1 + k * k * 0.18 + (k > 0 ? Math.sin(this.fuse * 40) * 0.015 : 0);
    this.flash = k > 0 && Math.sin(this.fuse * (8 + k * 22)) > 0 ? 0.9 : 0;
  }
  hurt(amount, src = {}) {
    // explosions set creepers off
    if (src.type === 'explosion' && this.deathT < 0 && Math.random() < 0.6) { this.fuse = Math.max(this.fuse, 1.2); this.hissing = true; }
    return super.hurt(amount, src);
  }
}
MOB_CLASSES.creeper = Creeper;

// ===================================================================== skeleton
{
  const BONE = '#d9d5c6', BONE2 = '#a9a493', GAP = '#26231f', WOOD = '#6a4a26', STRING = '#e8e4d8';
  const ribs = [];
  for (let k = 0; k < 4; k++) ribs.push(box([-3.6, 3.2 + k * 2.2, -1.65], [7.2, 0.7, 0.12], GAP, PAT.flat), box([-3.6, 3.2 + k * 2.2, 1.55], [7.2, 0.7, 0.12], GAP, PAT.flat));
  ribs.push(box([-0.5, 0, -1.66], [1, 12, 0.12], BONE2, PAT.flat));   // breastbone
  MODELS.skeleton = humanoid({
    legH: 12, legW: 2, tw: 7, th: 12, td: 3, aw: 2, ah: 12, hw: 8, hh: 8, hd: 8,
    colors: { leg: BONE, leg2: BONE2, body: BONE, body2: BONE2, arm: BONE, arm2: BONE2, head: BONE, head2: BONE2, eye: '#0a0908' },
    legPat: PAT.noise, bodyPat: PAT.noise, armPat: PAT.noise, headPat: PAT.noise, eyeY: 3.6, eyeW: 2, eyeH: 2,
    bodyExtra: ribs,
    headExtra: [
      box([-1.2, 2.4, -4.08], [0.8, 1, 0.12], GAP, PAT.flat), box([0.4, 2.4, -4.08], [0.8, 1, 0.12], GAP, PAT.flat),   // nose holes
      box([-2.8, 0.6, -4.08], [5.6, 0.6, 0.12], GAP, PAT.flat),                                                          // jaw line
      box([-2.4, 1.2, -4.08], [0.5, 0.6, 0.1], BONE2, PAT.flat), box([-0.9, 1.2, -4.08], [0.5, 0.6, 0.1], BONE2, PAT.flat), box([0.6, 1.2, -4.08], [0.5, 0.6, 0.1], BONE2, PAT.flat), box([1.9, 1.2, -4.08], [0.5, 0.6, 0.1], BONE2, PAT.flat),
    ],
    // a bow gripped in the right hand: the stave runs across the hand, the string a little behind it
    handR: [
      box([-0.6, -11.5, -6.5], [1.2, 1.2, 13], WOOD, PAT.bark),
      box([-0.5, -11.4, -7.4], [1, 1, 1.2], WOOD, PAT.bark), box([-0.5, -11.4, 6.2], [1, 1, 1.2], WOOD, PAT.bark),
      box([-0.15, -9.2, -6.8], [0.3, 0.3, 13.6], STRING, PAT.flat),
    ],
    anim: 'skeleton',
  });
}
MOBS.skeleton = Object.assign({}, MOBS.shambler, {
  id: 'skeleton', name: 'Skeleton', type: 'hostile', hp: 20, speed: 2.5, runSpeed: 3.0, size: [0.6, 1.95], model: MODELS.skeleton,
  drops: [['bone', 0, 2], ['arrow', 0, 2], ['bow', 0, 1, 0.06]], sounds: { idle: 'clatter', hurt: 'clatter', death: 'clatter' }, idleSound: 0.06,
  attack: { ranged: true, dmg: 3, cd: 2.1, proj: 'arrow', range: 16, min: 5 }, burnsInDay: true, xp: 5, follow: 20,
});
ANIMS.skeleton = (m, P, t) => {
  ANIMS.biped(m, P, t);
  if (m.aiming) {
    // draw: the bow arm holds out, the string hand pulls back to the cheek and lets go when it shoots
    const draw = Math.min(1, Math.max(0, 1 - (m.attackCD || 0) / 1.2));
    set(m, P, 'armL', 0.1 + draw * 0.2, -0.9 - draw * 0.25);
    if (m.attackAnim > 0) set(m, P, 'armL', -0.3);
  }
  set(m, P, 'head', 0, 0, Math.sin(t * 1.3 + m.id) * 0.05);
};

// ===================================================================== spawn tables
NIGHT_SPAWNS.default.push(['skeleton', 8, 1, 2], ['creeper', 6, 1, 1]);
for (const k of Object.keys(NIGHT_SPAWNS)) {
  if (k === 'default') continue;
  const t = NIGHT_SPAWNS[k];
  if (t.some(e => e[0] === 'shambler')) t.push(['skeleton', 6, 1, 2], ['creeper', 4, 1, 1]);
}
CAVE_SPAWNS.push(['skeleton', 9, 1, 2], ['creeper', 6, 1, 1]);

// ===================================================================== spawners and the den
export function installCaves(game) {
  const spawners = () => (game.meta.spawners = game.meta.spawners || {});
  const dens = () => (game.meta.dens = game.meta.dens || {});

  const prevStruct = game.onStructures;
  game.onStructures = (c, fresh) => {
    if (prevStruct) prevStruct(c, fresh);
    if (!c.structures || !game.meta) return;
    for (const s of c.structures) {
      if (s.type === 'spawner' && fresh) spawners()[s.x + ',' + s.y + ',' + s.z] = { x: s.x, y: s.y, z: s.z, mob: s.mob, t: rnd(2, 6) };
      else if (s.type === 'den' && !dens()[s.id]) dens()[s.id] = { id: s.id, x: s.x, y: s.y, z: s.z, r: s.r, defeated: false };
    }
  };

  let tick = 0, denT = 0, queen = null;
  const prev = game.extUpdate;
  game.extUpdate = (dt) => {
    if (prev) prev(dt);
    const p = game.player, w = game.world;
    if (!p || !game.meta || game.state !== 'playing') return;
    // ---- spawners
    tick -= dt;
    if (tick <= 0) {
      tick = 0.25;
      const S = spawners();
      for (const key in S) {
        const s = S[key];
        const dx = s.x + 0.5 - p.x, dz = s.z + 0.5 - p.z;
        if (Math.abs(dx) > 40 || Math.abs(dz) > 40 || !w.isLoaded(s.x, s.z)) continue;
        if (w.getBlock(s.x, s.y, s.z) !== B.monster_spawner) { delete S[key]; continue; }
        const d = Math.hypot(dx, s.y + 0.5 - p.y, dz);
        if (d > 16) continue;
        // a lick of flame and smoke inside the cage while it is awake
        for (let k = 0; k < 2; k++) game.particles.add({ x: s.x + rnd(0.2, 0.8), y: s.y + rnd(0.2, 0.8), z: s.z + rnd(0.2, 0.8), vx: 0, vy: rnd(0.3, 0.8), vz: 0, size: rnd(0.05, 0.1), r: 1, g: rnd(0.4, 0.6), b: 0.15, a: 1, a0: 1, fade: true, layer: -2, life: rnd(0.3, 0.6), emis: 4, add: true });
        game.particles.add({ x: s.x + rnd(0.2, 0.8), y: s.y + 0.8, z: s.z + rnd(0.2, 0.8), vx: 0, vy: 0.6, vz: 0, size: 0.12, size0: 0.12, grow: 0.8, r: 0.12, g: 0.12, b: 0.12, a: 0.5, a0: 0.5, fade: true, layer: -1, life: 1.2, drag: 1, light: 0.3 });
        s.t -= 0.25;
        if (s.t > 0) continue;
        s.t = rnd(9, 18);
        if (game.settings.difficulty === 'peaceful' || p.creative) continue;
        const around = game.entities.count(e => e.kind === s.mob && !e.dead && Math.hypot(e.x - s.x, e.y - s.y, e.z - s.z) < 10);
        if (around >= 4) continue;
        const n = 1 + Math.floor(Math.random() * 3);
        for (let i = 0, made = 0; i < 12 && made < n; i++) {
          const x = Math.floor(s.x + rnd(-3.5, 4.5)), z = Math.floor(s.z + rnd(-3.5, 4.5));
          for (const y of [s.y, s.y + 1, s.y - 1]) {
            const fl = w.getBlock(x, y - 1, z), a = w.getBlock(x, y, z), b = w.getBlock(x, y + 1, z);
            if (!fl || !BLOCKS[fl].solid || IS_LIQUID[fl] || (a && BLOCKS[a].solid) || (b && BLOCKS[b].solid) || IS_LIQUID[a]) continue;
            const m = game.mobs.spawn(s.mob, x + 0.5, y + 0.05, z + 0.5);
            m.target = p;
            for (let k = 0; k < 8; k++) game.particles.add({ x: x + 0.5 + rnd(-0.4, 0.4), y: y + rnd(0.2, 1.6), z: z + 0.5 + rnd(-0.4, 0.4), vx: rnd(-0.5, 0.5), vy: rnd(0.2, 1), vz: rnd(-0.5, 0.5), size: 0.14, size0: 0.14, grow: 1, r: 0.15, g: 0.12, b: 0.14, a: 0.7, a0: 0.7, fade: true, layer: -1, life: 1, drag: 2, light: 0.3 });
            made++;
            break;
          }
        }
      }
    }
    // ---- the den: walk into it and its queen comes down
    denT -= dt;
    if (denT > 0) return;
    denT = 1;
    if (queen && (queen.dead || queen.deathT >= 0)) {
      const D = dens()[queen.denId];
      if (D && queen.hp <= 0) {
        D.defeated = true;
        game.ui.notice('The Broodmother is slain. The den falls silent.');
        // her nests die with her
        for (const key in spawners()) { const s = spawners()[key]; if (Math.hypot(s.x - D.x, s.z - D.z) < D.r + 3 && Math.abs(s.y - D.y) < 6) { w.setBlock(s.x, s.y, s.z, 0, 0); delete spawners()[key]; } }
      }
      queen = null;
    }
    if (queen) {
      // she won't follow you out of her den for long
      if (queen.distTo(p.x, p.y, p.z) > 90) { queen.dead = true; queen = null; }
      return;
    }
    if (game.settings.difficulty === 'peaceful' || p.creative || p.dead) return;
    for (const id in dens()) {
      const D = dens()[id];
      if (D.defeated) continue;
      if (Math.hypot(D.x - p.x, D.z - p.z) > D.r * 0.75 || Math.abs(p.y - D.y) > 10) continue;
      if (game.entities.list.some(e => e.isElite && !e.dead && e.deathT < 0)) return;
      const m = createMob(game, 'broodmother', D.x, D.y + 4, D.z, {});
      m.denId = id; m.target = p; m.vy = -2;
      game.entities.add(m);
      queen = m;
      game.ui.subtitle('The Broodmother', 'Queen of the deep tunnels', 4);
      game.audio.play('boss_sting');
      game.audio.mob('hiss', m, 0.5);
      game.camShake = Math.max(game.camShake || 0, 0.5);
      for (let k = 0; k < 40; k++) game.particles.add({ x: D.x + rnd(-3, 3), y: D.y + rnd(6, 12), z: D.z + rnd(-3, 3), vx: 0, vy: -rnd(1, 3), vz: 0, size: rnd(0.05, 0.12), r: 0.5, g: 0.45, b: 0.4, a: 0.8, a0: 0.8, fade: true, layer: -1, life: rnd(1, 2.5), grav: 3, light: 0.4 });
      return;
    }
  };
}
