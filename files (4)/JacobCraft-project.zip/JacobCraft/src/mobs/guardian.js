// The Hearthwarden: every village's guardian. Villagers raised it from what they had to hand: fieldstone for a body,
// oak beams for a frame, a little shingle roof for a brow, and their oldest hearth-fire set burning in its chest.
// It walks the lanes by day and stands by the well at night, its fire lighting the square. Monsters that come into
// the village meet its fists (a two-handed slam that knocks everything back); harm a villager and it remembers.
import { Mob, MOB_CLASSES, createMob } from './mobs.js';
import { MOBS } from './defs.js';
import { MODELS, PAT, box, part, finalize } from './models.js';
import { ANIMS } from './anim.js';

const set = (m, P, name, rx = 0, ry = 0, rz = 0, tx = 0, ty = 0, tz = 0) => {
  const i = m.model.index[name];
  if (i === undefined) return;
  const p = P[i];
  p[0] += rx; p[1] += ry; p[2] += rz; p[3] += tx; p[4] += ty; p[5] += tz;
};
const rnd = (a, b) => a + Math.random() * (b - a);

{
  const ST = '#8a8a84', ST2 = '#6a6a64', MOSS = '#5a7a3a', OAK = '#7a5432', OAK2 = '#5a3a20', IRON = '#3a3a40', FIRE = '#ffa040', ROOF = '#7a3a2a', ROOF2 = '#5a2a1e';
  const parts = [];
  for (const [n, x] of [['legL', -3.4], ['legR', 3.4]]) parts.push(part(n, null, [x, 16, 0], [
    box([-2.9, -16, -2.9], [5.8, 16.5, 5.8], ST, PAT.rock, ST2), box([-3.1, -16, -3.6], [6.2, 3.2, 7], ST2, PAT.rock),
    box([-3.0, -9, -3.0], [6, 1.4, 6], OAK, PAT.bark, OAK2), box([-2.95, -3, -2.95], [1.6, 2.4, 1.2], MOSS, PAT.moss),
  ]));
  parts.push(part('body', null, [0, 16, 0], [
    box([-7, 0, -4.6], [14, 17, 9.2], ST, PAT.rock, ST2),
    box([-7.3, 3, -4.9], [14.6, 1.6, 9.8], OAK, PAT.bark, OAK2), box([-7.3, 13, -4.9], [14.6, 1.6, 9.8], OAK, PAT.bark, OAK2),   // timber bands
    box([-6.6, 0, -4.9], [1.4, 17, 0.4], OAK, PAT.bark, OAK2), box([5.2, 0, -4.9], [1.4, 17, 0.4], OAK, PAT.bark, OAK2),
    box([-3.2, 6, -4.95], [6.4, 5.4, 0.3], IRON, PAT.metal), box([-2.6, 6.5, -4.98], [5.2, 4.4, 0.12], FIRE, PAT.glow),          // the hearth in its chest
    box([-1.4, 6.5, -5.05], [0.5, 4.4, 0.12], IRON, PAT.metal), box([0.9, 6.5, -5.05], [0.5, 4.4, 0.12], IRON, PAT.metal),
    box([-7.2, 15, -3.6], [3.6, 2.4, 7.2], MOSS, PAT.moss), box([4.4, 9, 4.3], [2.4, 3.6, 0.6], MOSS, PAT.moss),
    box([-1.2, 17, -1.2], [2.4, 2.8, 2.4], IRON, PAT.metal),                                                                    // chimney pipe at the neck
  ]));
  for (const [n, x] of [['armL', -9.2], ['armR', 9.2]]) parts.push(part(n, 'body', [x, 31.5, 0], [
    box([-3.2, -2.2, -3.6], [6.4, 4.4, 7.2], OAK, PAT.bark, OAK2),                                                               // beam pauldron
    box([-2.4, -17, -2.4], [4.8, 16, 4.8], ST, PAT.rock, ST2), box([-2.6, -12, -2.6], [5.2, 1.4, 5.2], OAK, PAT.bark, OAK2),
    box([-3.2, -22.5, -3.2], [6.4, 5.6, 6.4], ST2, PAT.rock, ST),                                                                // fist
  ]));
  parts.push(part('head', 'body', [0, 33.5, -0.6], [
    box([-3.6, 0, -3.4], [7.2, 6, 6.8], ST, PAT.rock, ST2),
    box([-2.6, 2.4, -3.48], [1.5, 1.2, 0.12], FIRE, PAT.glow), box([1.1, 2.4, -3.48], [1.5, 1.2, 0.12], FIRE, PAT.glow),          // ember eyes
    box([-1.4, 0.9, -3.45], [2.8, 0.5, 0.1], '#3a3a36', PAT.flat),
    // a little cottage roof for a brow
    box([-4.6, 6, -4.4], [9.2, 1.2, 8.8], ROOF, PAT.rock, ROOF2), box([-3.6, 7.2, -4.4], [7.2, 1.2, 8.8], ROOF, PAT.rock, ROOF2), box([-2.2, 8.4, -4.4], [4.4, 1.2, 8.8], ROOF, PAT.rock, ROOF2),
    box([-0.8, 9.6, -4.4], [1.6, 0.8, 8.8], OAK2, PAT.bark), box([1.6, 8.4, 0.5], [1.4, 3, 1.4], '#8a3a2a', PAT.rock),
  ]));
  MODELS.hearthwarden = finalize({ parts, anim: 'hearth', height: 46 });
}

ANIMS.hearth = (m, P, t) => {
  const id = m.mid || 0;
  const s = Math.sin(m.walkPhase * 0.55) * m.walkAmt;
  set(m, P, 'legL', s * 0.5); set(m, P, 'legR', -s * 0.5);
  set(m, P, 'body', 0, 0, Math.sin(m.walkPhase * 0.55) * 0.05 * m.walkAmt, 0, Math.abs(s) * 0.6);
  const wind = m.windAnim || 0, atk = m.attackAnim || 0;
  const swing = -s * 0.4 + Math.sin(t * 0.8 + id) * 0.03;
  set(m, P, 'armL', swing - wind * 2.7 + atk * 2.2, 0, 0.08 + wind * 0.2);
  set(m, P, 'armR', -swing - wind * 2.7 + atk * 2.2, 0, -0.08 - wind * 0.2);
  set(m, P, 'head', m.headPitch * 0.5, m.headYaw * 0.7, Math.sin(t * 0.5 + id) * 0.04);
};

MOBS.hearthwarden = Object.assign({}, MOBS.cow, {
  id: 'hearthwarden', name: 'Hearthwarden', type: 'guardian', hp: 100, speed: 1.3, runSpeed: 2.6, size: [1.5, 2.85], model: MODELS.hearthwarden,
  drops: [['cobblestone', 4, 8], ['oak_planks', 2, 4], ['coal', 2, 4]], sounds: { idle: 'rumble', hurt: 'creak', death: 'rumble' }, food: [], idleSound: 0.02,
  knockRes: 0.9, xp: 0, attack: { dmg: 12, reach: 2.8, cd: 1.8 }, scaleSound: 0.5, sleeps: false,
});

class Hearthwarden extends Mob {
  constructor(game, kind, x, y, z, opts = {}) {
    super(game, kind, x, y, z, Object.assign({ persistent: true }, opts));
    this.data = Object.assign({ home: [x, y, z], village: null }, opts.data || {});
    this.isGuardian = true;
  }
  extraData() { return this.data; }
  loadExtra(d) { this.data = Object.assign(this.data || {}, d); }
  brainAnimal(dt) {
    const g = this.game, p = g.player, H = this.data.home;
    this.sleeping = false;
    // pick a fight: a monster in the village, or whoever hurt its people
    this.scanT = (this.scanT || 0) - dt;
    if (this.scanT <= 0) {
      this.scanT = 0.5;
      if (this.target && (this.target.dead || this.target.deathT >= 0 || (this.target === p && (this.angryT <= 0 || p.dead || p.creative)))) this.target = null;
      if (!this.target) {
        let best = null, bd = 18;
        for (const e of g.entities.list) {
          if (e.type !== 'mob' || !e.isHostile || e.dead || e.deathT >= 0 || e.isBoss) continue;
          const d = e.distTo(this.x, this.y, this.z);
          if (d < bd && Math.hypot(e.x - H[0], e.z - H[2]) < 40) { bd = d; best = e; }
        }
        this.target = best;
      }
    }
    if (this.angryT > 0) this.angryT -= dt;
    const t = this.target;
    if (this.windT > 0) {
      this.windT -= dt; this.windAnim = Math.min(1, 1 - this.windT / 0.55); this.mx = this.mz = 0;
      if (t) this.lookAt = t;
      if (this.windT <= 0) this.slam();
      return;
    }
    this.windAnim = 0;
    if (t) {
      this.lookAt = t;
      const d = Math.hypot(t.x - this.x, t.z - this.z);
      if (d > 2.4) { this.seekTarget(t, this.def.runSpeed); }
      if (d < this.def.attack.reach + (t.hw || 0.3) && this.attackCD <= 0) { this.windT = 0.55; this.attackCD = this.def.attack.cd; g.audio.mob('rumble', this, 0.6); }
      if (Math.hypot(this.x - H[0], this.z - H[2]) > 44) this.target = null;   // never strays far from home
      return;
    }
    // no trouble: walk the lanes by day, keep the well at night (where its fire lights the square)
    const night = g.dayTime > 0.78 || g.dayTime < 0.22;
    const dh = Math.hypot(this.x - H[0], this.z - H[2]);
    if (night) {
      if (dh > 3) this.seekTarget({ x: H[0] + 2.5, y: H[1], z: H[2] + 2.5 }, this.def.speed);
      else this.lookAt = Math.hypot(p.x - this.x, p.z - this.z) < 10 ? p : null;
      return;
    }
    if (dh > 22) { this.goal = [H[0] + rnd(-6, 6), H[2] + rnd(-6, 6)]; this.state = 'walk'; this.stateT = 6; }
    this.wander(dt, this.def.speed * 0.8);
    if (Math.hypot(p.x - this.x, p.z - this.z) < 6) this.lookAt = p;
  }
  slam() {
    const g = this.game, t = this.target;
    this.attackAnim = 1;
    const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
    const cx = this.x + fx * 1.8, cz = this.z + fz * 1.8;
    g.audio.play('mace_smash', { x: cx, y: this.y, z: cz });
    g.camShake = Math.max(g.camShake || 0, Math.max(0, 0.3 - this.distTo(g.player.x, g.player.y, g.player.z) * 0.02));
    for (let i = 0; i < 24; i++) { const a = i / 24 * Math.PI * 2; g.particles.add({ x: cx + Math.cos(a) * 0.5, y: this.y + 0.1, z: cz + Math.sin(a) * 0.5, vx: Math.cos(a) * 5, vy: rnd(0.5, 2), vz: Math.sin(a) * 5, size: 0.22, size0: 0.22, grow: 1.4, r: 0.55, g: 0.52, b: 0.46, a: 0.6, a0: 0.6, fade: true, layer: -1, life: 0.6, drag: 3, light: g.particles.lightAt(cx, this.y + 1, cz) }); }
    const p = g.player;
    const hitPlayer = t === p || (this.angryT > 0 && this.target === p);
    for (const e of [p, ...g.entities.list]) {
      if (e === this || e.dead) continue;
      const isP = e === p;
      if (isP && !hitPlayer) continue;
      if (!isP && (e.type !== 'mob' || !(e.isHostile || e === t) || e.isBoss)) continue;
      const d = Math.hypot(e.x - cx, e.z - cz);
      if (d > 2.6 || Math.abs(e.y - this.y) > 2.5) continue;
      const kx = (e.x - this.x) / (Math.hypot(e.x - this.x, e.z - this.z) || 1), kz = (e.z - this.z) / (Math.hypot(e.x - this.x, e.z - this.z) || 1);
      if (isP) { if (p.damage(this.def.attack.dmg * 0.6, 'mob', false, this)) { p.knockX = kx * 9; p.knockZ = kz * 9; p.vy = 8; } }
      else { e.hurtT = 0; e.hurt(this.def.attack.dmg, { entity: this, dir: [kx, 0, kz], knock: 1.8 }); e.vy = Math.max(e.vy, 7); }
    }
  }
  hurt(amount, src = {}) {
    const r = super.hurt(amount, Object.assign({}, src, { knock: (src.knock ?? 1) * 0.2 }));
    if (r && src.entity === this.game.player) { this.angryT = 25; this.target = this.game.player; }
    else if (r && src.entity && src.entity.isHostile) this.target = src.entity;
    return r;
  }
  die(src) {
    super.die(src);
    const g = this.game;
    if (g.meta && this.data.village) { g.meta.guardians = g.meta.guardians || {}; g.meta.guardians[this.data.village] = { fallenDay: g.day || 0 }; }
  }
  update(dt) {
    super.update(dt);
    // sparks and a breath of smoke from its chest fire
    if (this.deathT < 0 && Math.random() < dt * 3) {
      const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
      this.game.particles.ember(this.x + fx * 0.35, this.y + 1.55, this.z + fz * 0.35, 0.15);
      if (Math.random() < 0.3) this.game.particles.smoke(this.x, this.y + 3.05, this.z, 1, 0.25);
    }
  }
}
MOB_CLASSES.hearthwarden = Hearthwarden;

// one Hearthwarden per village; if it falls, the villagers raise another a few days later
export function installGuardians(game) {
  let t = 5;
  const prevExt = game.extUpdate;
  game.extUpdate = (dt) => {
    prevExt && prevExt(dt);
    const p = game.player;
    if (!p || !game.meta || (t -= dt) > 0) return;
    t = 8;
    const G = game.meta.guardians = game.meta.guardians || {};
    const seen = new Set();
    for (const e of game.entities.list) {
      if (!e.isVillager || e.kind === 'wizard' || !e.data || !e.data.village || !e.data.meet) continue;
      const vid = e.data.village;
      if (seen.has(vid)) continue;
      seen.add(vid);
      if (Math.hypot(e.x - p.x, e.z - p.z) > 96) continue;
      const rec = G[vid];
      if (rec && (rec.alive || (rec.fallenDay !== undefined && (game.day || 0) - rec.fallenDay < 3))) continue;
      if (game.entities.list.some(o => o.kind === 'hearthwarden' && o.data && o.data.village === vid && !o.dead)) { G[vid] = { alive: true }; continue; }
      const [mx, my, mz] = e.data.meet;
      if (!game.world.isLoaded(mx, mz)) continue;
      const gy = game.mobs.groundAt(mx + 3, mz + 3);
      const w = createMob(game, 'hearthwarden', mx + 3.5, gy > 0 ? gy : my, mz + 3.5, { data: { home: [mx, my, mz], village: vid } });
      game.entities.add(w);
      G[vid] = { alive: true };
    }
  };
}
