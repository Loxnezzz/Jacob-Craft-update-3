// Builds Jacob Craft into ONE self-contained HTML file that runs anywhere:
//   - double-click it (opens from file:// - no server, no dev mode, no Python)
//   - or upload it to any static host (GitHub Pages, Netlify Drop, Cloudflare Pages, ...)
//
// The game source in src/ is NOT modified. The only transformation is that the two
// `new Worker(new URL(..., import.meta.url), {type:'module'})` calls (world generation + chunk
// meshing) are swapped for Blob-URL workers built from the same worker code, because browsers
// refuse to load ES-module files / module workers from file://.
//
// Usage:   npm install        (once, installs esbuild)
//          npm run build      (writes dist/index.html)

import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, mkdirSync, statSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
let esbuild;
try { esbuild = require('esbuild'); } catch (e) {
  if (process.env.ESBUILD_PATH) esbuild = require(process.env.ESBUILD_PATH);
  else { console.error('esbuild not found. Run `npm install` first.'); process.exit(1); }
}

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const OUT = join(ROOT, 'dist');
const p = (...a) => join(ROOT, ...a);

const COMMON = {
  bundle: true,
  format: 'iife',
  target: 'es2020',
  write: false,
  // whitespace + syntax only: identifiers keep their names, so behaviour is identical to the dev build
  minifyWhitespace: true,
  minifySyntax: true,
  legalComments: 'none',
  logLevel: 'warning',
};

const bundle = async (entry, extra = {}) => {
  const r = await esbuild.build({ ...COMMON, entryPoints: [p(entry)], ...extra });
  return r.outputFiles[0].text;
};

// 1) the two workers, each as a standalone classic-script bundle
const genSrc = await bundle('src/workers/genWorker.js');
const meshSrc = await bundle('src/workers/meshWorker.js');

// 2) the main game bundle, with worker construction redirected to the Blob workers
const WORKER_RE = /new Worker\(new URL\('\.\.\/workers\/(genWorker|meshWorker)\.js', import\.meta\.url\), \{ type: 'module' \}\)/g;
const blobWorkers = {
  name: 'jc-blob-workers',
  setup(b) {
    b.onLoad({ filter: /world[\\/]world\.js$/ }, (args) => {
      let n = 0;
      const text = readFileSync(args.path, 'utf8').replace(WORKER_RE, (_, w) => { n++; return `window.__jcMakeWorker('${w === 'genWorker' ? 'gen' : 'mesh'}')`; });
      if (n !== 2) throw new Error(`expected to rewrite 2 Worker constructors in world.js, rewrote ${n}`);
      return { contents: text, loader: 'js', resolveDir: dirname(args.path) };
    });
  },
};
const mainSrc = await bundle('src/main.js', { plugins: [blobWorkers] });

// 3) assemble the HTML
// Anything placed inside an inline <script> must not contain "</script" or "<!--".
const safe = (s) => s.replace(/<\/script/gi, '<\\/script').replace(/<!--/g, '<\\!--');

const workerBoot = `(function(){
  var src = { gen: ${JSON.stringify(genSrc)}, mesh: ${JSON.stringify(meshSrc)} };
  var urls = {};
  window.__jcMakeWorker = function (name) {
    if (!urls[name]) urls[name] = URL.createObjectURL(new Blob([src[name]], { type: 'text/javascript' }));
    return new Worker(urls[name]);
  };
})();`;

let html = readFileSync(p('index.html'), 'utf8');
const css = readFileSync(p('style.css'), 'utf8');

const before = html;
html = html
  .replace('<link rel="stylesheet" href="style.css">', () => `<style>\n${css}\n</style>`)
  .replace('<script type="module" src="src/main.js"></script>', () => `<script>\n${safe(workerBoot)}\n</script>\n<script>\n${safe(mainSrc)}\n</script>`);
if (html === before || html.includes('src/main.js') || html.includes('href="style.css"')) {
  throw new Error('index.html did not have the expected <link>/<script> tags to inline');
}

mkdirSync(OUT, { recursive: true });
writeFileSync(join(OUT, 'index.html'), html);
const kb = (f) => (statSync(f).size / 1024).toFixed(0) + ' KB';
console.log(`built dist/index.html (${kb(join(OUT, 'index.html'))})  [game ${(mainSrc.length / 1024).toFixed(0)} KB, gen worker ${(genSrc.length / 1024).toFixed(0)} KB, mesh worker ${(meshSrc.length / 1024).toFixed(0)} KB]`);
